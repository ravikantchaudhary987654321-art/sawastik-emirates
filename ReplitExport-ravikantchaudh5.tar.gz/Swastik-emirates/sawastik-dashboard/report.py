"""PDF report generator for Sawastik Emirates portfolio."""
import io
import datetime

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    HRFlowable,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# ── Brand colours ─────────────────────────────────────────────────────────────
BRAND_DARK   = colors.HexColor("#1a2e44")   # deep navy
BRAND_BLUE   = colors.HexColor("#2563eb")   # accent blue
BRAND_LIGHT  = colors.HexColor("#dbeafe")   # pale blue
BRAND_GREEN  = colors.HexColor("#16a34a")   # positive growth
BRAND_RED    = colors.HexColor("#dc2626")   # negative growth
BRAND_GREY   = colors.HexColor("#6b7280")   # muted text
ROW_ALT      = colors.HexColor("#f1f5f9")   # alternate row tint

PAGE_W, PAGE_H = A4
MARGIN = 18 * mm


def _styles():
    ss = getSampleStyleSheet()
    base = ss["Normal"]

    def _p(name, **kw):
        return ParagraphStyle(name, parent=base, **kw)

    return {
        "cover_title":  _p("cover_title",  fontSize=26, textColor=BRAND_DARK,
                            fontName="Helvetica-Bold", alignment=TA_CENTER, spaceAfter=4),
        "cover_sub":    _p("cover_sub",    fontSize=13, textColor=BRAND_BLUE,
                            fontName="Helvetica", alignment=TA_CENTER, spaceAfter=2),
        "cover_meta":   _p("cover_meta",   fontSize=9,  textColor=BRAND_GREY,
                            fontName="Helvetica", alignment=TA_CENTER),
        "section":      _p("section",      fontSize=13, textColor=BRAND_DARK,
                            fontName="Helvetica-Bold", spaceBefore=14, spaceAfter=4),
        "body":         _p("body",         fontSize=9,  textColor=colors.black,
                            fontName="Helvetica", spaceAfter=2),
        "footer":       _p("footer",       fontSize=8,  textColor=BRAND_GREY,
                            fontName="Helvetica", alignment=TA_CENTER),
        "kpi_label":    _p("kpi_label",    fontSize=8,  textColor=BRAND_GREY,
                            fontName="Helvetica", alignment=TA_CENTER),
        "kpi_value":    _p("kpi_value",    fontSize=14, textColor=BRAND_DARK,
                            fontName="Helvetica-Bold", alignment=TA_CENTER),
        "kpi_delta":    _p("kpi_delta",    fontSize=8,  textColor=BRAND_GREEN,
                            fontName="Helvetica-Bold", alignment=TA_CENTER),
        "kpi_delta_neg":_p("kpi_delta_neg",fontSize=8, textColor=BRAND_RED,
                            fontName="Helvetica-Bold", alignment=TA_CENTER),
        "th":           _p("th",           fontSize=8,  textColor=colors.white,
                            fontName="Helvetica-Bold", alignment=TA_CENTER),
        "td":           _p("td",           fontSize=8,  textColor=colors.black,
                            fontName="Helvetica", alignment=TA_LEFT),
        "td_r":         _p("td_r",         fontSize=8,  textColor=colors.black,
                            fontName="Helvetica", alignment=TA_RIGHT),
        "td_c":         _p("td_c",         fontSize=8,  textColor=colors.black,
                            fontName="Helvetica", alignment=TA_CENTER),
        "td_green":     _p("td_green",     fontSize=8,  textColor=BRAND_GREEN,
                            fontName="Helvetica-Bold", alignment=TA_RIGHT),
        "td_red":       _p("td_red",       fontSize=8,  textColor=BRAND_RED,
                            fontName="Helvetica-Bold", alignment=TA_RIGHT),
    }


def _table_style(col_count, header_rows=1):
    return TableStyle([
        ("BACKGROUND",    (0, 0), (-1, header_rows - 1), BRAND_DARK),
        ("TEXTCOLOR",     (0, 0), (-1, header_rows - 1), colors.white),
        ("FONTNAME",      (0, 0), (-1, header_rows - 1), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS",(0, header_rows), (-1, -1), [colors.white, ROW_ALT]),
        ("GRID",          (0, 0), (-1, -1), 0.3, colors.HexColor("#e2e8f0")),
        ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING",   (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 5),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
    ])


def _aed(v):
    return f"AED {int(v):,}"


def _pct(v):
    sign = "+" if v >= 0 else ""
    return f"{sign}{v:.1f}%"


def generate_report(
    assets: list,
    valuations: list,
    total_portfolio: int,
    total_investment: int,
    net_gain: int,
    net_gain_pct: float,
    active_assets: int,
    avg_share: float,
    generated_by: str = "Sawastik Emirates",
) -> bytes:
    """Return PDF bytes for the portfolio report."""

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=MARGIN,
        rightMargin=MARGIN,
        topMargin=MARGIN,
        bottomMargin=MARGIN,
    )

    S = _styles()
    story = []
    usable_w = PAGE_W - 2 * MARGIN
    today_str = datetime.date.today().strftime("%d %B %Y")

    # ── Cover header ─────────────────────────────────────────────────────────
    story.append(Spacer(1, 8 * mm))
    story.append(Paragraph("Sawastik Emirates", S["cover_title"]))
    story.append(Paragraph("Asset &amp; Finance Manager — Portfolio Report", S["cover_sub"]))
    story.append(Paragraph(f"Generated on {today_str} &nbsp;|&nbsp; Prepared by {generated_by}", S["cover_meta"]))
    story.append(Spacer(1, 3 * mm))
    story.append(HRFlowable(width="100%", thickness=2, color=BRAND_BLUE))
    story.append(Spacer(1, 6 * mm))

    # ── KPI Banner (5 cards in a 1-row table) ────────────────────────────────
    story.append(Paragraph("Key Performance Indicators", S["section"]))

    gain_style = S["kpi_delta"] if net_gain >= 0 else S["kpi_delta_neg"]

    kpi_data = [[
        [Paragraph("Total Portfolio Value", S["kpi_label"]),
         Paragraph(_aed(total_portfolio),   S["kpi_value"])],
        [Paragraph("Total Investment",      S["kpi_label"]),
         Paragraph(_aed(total_investment),  S["kpi_value"])],
        [Paragraph("Net Gain",              S["kpi_label"]),
         Paragraph(_aed(net_gain),          S["kpi_value"]),
         Paragraph(_pct(net_gain_pct),      gain_style)],
        [Paragraph("Active Assets",         S["kpi_label"]),
         Paragraph(f"{active_assets} / {len(assets)}", S["kpi_value"])],
        [Paragraph("Avg Sawastik Share",    S["kpi_label"]),
         Paragraph(f"{avg_share:.1f}%",     S["kpi_value"])],
    ]]

    kpi_col_w = usable_w / 5
    kpi_table = Table(kpi_data, colWidths=[kpi_col_w] * 5, rowHeights=None)
    kpi_table.setStyle(TableStyle([
        ("BOX",           (0, 0), (-1, -1), 0.5, BRAND_BLUE),
        ("INNERGRID",     (0, 0), (-1, -1), 0.5, BRAND_BLUE),
        ("BACKGROUND",    (0, 0), (-1, -1), BRAND_LIGHT),
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING",    (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING",   (0, 0), (-1, -1), 4),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
    ]))
    story.append(kpi_table)
    story.append(Spacer(1, 6 * mm))

    # ── Asset Portfolio Table ─────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5, color=BRAND_LIGHT))
    story.append(Paragraph("Asset Portfolio", S["section"]))

    col_widths_assets = [
        usable_w * 0.22,  # Asset Name
        usable_w * 0.13,  # Category
        usable_w * 0.18,  # Location
        usable_w * 0.17,  # Total Value
        usable_w * 0.10,  # S.Share%
        usable_w * 0.13,  # S.Value
        usable_w * 0.07,  # Status
    ]
    asset_rows = [[
        Paragraph("Asset Name",      S["th"]),
        Paragraph("Category",        S["th"]),
        Paragraph("Location",        S["th"]),
        Paragraph("Total Value",     S["th"]),
        Paragraph("S.Share %",       S["th"]),
        Paragraph("S.Value (AED)",   S["th"]),
        Paragraph("Status",          S["th"]),
    ]]
    for a in assets:
        sawastik_share = next((p["share_pct"] for p in a["partners"] if p["name"] == "Sawastik"), 0.0)
        sawastik_val = a["total_value"] * sawastik_share / 100
        asset_rows.append([
            Paragraph(a["name"],             S["td"]),
            Paragraph(a["category"],         S["td_c"]),
            Paragraph(a["location"],         S["td"]),
            Paragraph(_aed(a["total_value"]),S["td_r"]),
            Paragraph(f"{sawastik_share:.0f}%", S["td_c"]),
            Paragraph(_aed(sawastik_val),    S["td_r"]),
            Paragraph(a["status"],           S["td_c"]),
        ])
    asset_table = Table(asset_rows, colWidths=col_widths_assets, repeatRows=1)
    asset_table.setStyle(_table_style(7))
    story.append(asset_table)
    story.append(Spacer(1, 6 * mm))

    # ── Asset Growth Summary ──────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5, color=BRAND_LIGHT))
    story.append(Paragraph("Asset Growth Summary", S["section"]))

    val_by_asset: dict = {}
    for v in valuations:
        aid = v.get("asset_id")
        val_by_asset.setdefault(aid, []).append(v)

    col_widths_growth = [
        usable_w * 0.22,
        usable_w * 0.13,
        usable_w * 0.17,
        usable_w * 0.17,
        usable_w * 0.14,
        usable_w * 0.09,
        usable_w * 0.08,
    ]
    growth_rows = [[
        Paragraph("Asset",            S["th"]),
        Paragraph("Category",         S["th"]),
        Paragraph("Initial Value",    S["th"]),
        Paragraph("Current Value",    S["th"]),
        Paragraph("Gain (AED)",       S["th"]),
        Paragraph("Growth %",         S["th"]),
        Paragraph("Records",          S["th"]),
    ]]
    for a in assets:
        v_list = sorted(val_by_asset.get(a["id"], []), key=lambda x: x.get("valuation_date", ""))
        if len(v_list) >= 2:
            first_v = int(v_list[0]["value"])
            last_v  = int(v_list[-1]["value"])
        elif len(v_list) == 1:
            first_v = last_v = int(v_list[0]["value"])
        else:
            first_v = last_v = a["total_value"]
        chg     = last_v - first_v
        chg_pct = (chg / first_v * 100) if first_v else 0.0
        rec_count = len(v_list)

        gain_cell_style = S["td_green"] if chg >= 0 else S["td_red"]
        growth_rows.append([
            Paragraph(a["name"],        S["td"]),
            Paragraph(a["category"],    S["td_c"]),
            Paragraph(_aed(first_v),    S["td_r"]),
            Paragraph(_aed(last_v),     S["td_r"]),
            Paragraph(_aed(chg),        gain_cell_style),
            Paragraph(_pct(chg_pct),    gain_cell_style),
            Paragraph(str(rec_count),   S["td_c"]),
        ])
    growth_table = Table(growth_rows, colWidths=col_widths_growth, repeatRows=1)
    growth_table.setStyle(_table_style(7))
    story.append(growth_table)
    story.append(Spacer(1, 6 * mm))

    # ── Partner Summary ───────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5, color=BRAND_LIGHT))
    story.append(Paragraph("Partner Summary", S["section"]))

    partner_map: dict = {}
    for a in assets:
        for p in a["partners"]:
            pn = p["name"]
            entry = partner_map.setdefault(pn, {"assets": 0, "total_value": 0.0, "shares": []})
            entry["assets"] += 1
            entry["total_value"] += a["total_value"] * p["share_pct"] / 100
            entry["shares"].append(p["share_pct"])

    col_widths_partners = [
        usable_w * 0.30,
        usable_w * 0.15,
        usable_w * 0.30,
        usable_w * 0.25,
    ]
    partner_rows = [[
        Paragraph("Partner",            S["th"]),
        Paragraph("Assets",             S["th"]),
        Paragraph("Total Invested",     S["th"]),
        Paragraph("Avg Share %",        S["th"]),
    ]]
    for pname, info in sorted(partner_map.items(), key=lambda x: -x[1]["total_value"]):
        avg_s = sum(info["shares"]) / len(info["shares"]) if info["shares"] else 0
        partner_rows.append([
            Paragraph(pname,                  S["td"]),
            Paragraph(str(info["assets"]),    S["td_c"]),
            Paragraph(_aed(info["total_value"]), S["td_r"]),
            Paragraph(f"{avg_s:.1f}%",        S["td_c"]),
        ])
    partner_table = Table(partner_rows, colWidths=col_widths_partners, repeatRows=1)
    partner_table.setStyle(_table_style(4))
    story.append(partner_table)
    story.append(Spacer(1, 6 * mm))

    # ── Valuation History Detail ──────────────────────────────────────────────
    if valuations:
        story.append(HRFlowable(width="100%", thickness=0.5, color=BRAND_LIGHT))
        story.append(Paragraph("Valuation History", S["section"]))

        col_widths_val = [
            usable_w * 0.30,
            usable_w * 0.14,
            usable_w * 0.20,
            usable_w * 0.12,
            usable_w * 0.24,
        ]
        val_rows = [[
            Paragraph("Asset",          S["th"]),
            Paragraph("Date",           S["th"]),
            Paragraph("Value (AED)",    S["th"]),
            Paragraph("Category",       S["th"]),
            Paragraph("Notes",          S["th"]),
        ]]
        sorted_vals = sorted(valuations, key=lambda x: (x.get("asset_name", ""), x.get("valuation_date", "")))
        for v in sorted_vals:
            val_rows.append([
                Paragraph(v.get("asset_name", ""),    S["td"]),
                Paragraph(str(v.get("valuation_date", ""))[:10], S["td_c"]),
                Paragraph(_aed(v.get("value", 0)),    S["td_r"]),
                Paragraph(v.get("category", ""),      S["td_c"]),
                Paragraph(v.get("notes", "") or "",   S["td"]),
            ])
        val_table = Table(val_rows, colWidths=col_widths_val, repeatRows=1)
        val_table.setStyle(_table_style(5))
        story.append(val_table)

    # ── Footer ────────────────────────────────────────────────────────────────
    story.append(Spacer(1, 8 * mm))
    story.append(HRFlowable(width="100%", thickness=1, color=BRAND_BLUE))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(
        f"Sawastik Emirates — Confidential Portfolio Report &nbsp;|&nbsp; {today_str} &nbsp;|&nbsp; "
        "For partner use only",
        S["footer"],
    ))

    doc.build(story)
    return buf.getvalue()
