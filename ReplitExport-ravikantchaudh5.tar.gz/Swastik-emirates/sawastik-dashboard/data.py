import os
import secrets
from datetime import datetime, timedelta

import bcrypt
import psycopg2
import psycopg2.extras
from contextlib import contextmanager

DATABASE_URL = os.environ.get("DATABASE_URL")


@contextmanager
def get_conn():
    conn = psycopg2.connect(DATABASE_URL)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── Assets ────────────────────────────────────────────────────────────────────

def load_assets():
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM assets ORDER BY id")
            assets = [dict(row) for row in cur.fetchall()]
            cur.execute("SELECT * FROM asset_partners ORDER BY asset_id, id")
            partners = cur.fetchall()

    partner_map = {}
    for p in partners:
        partner_map.setdefault(p["asset_id"], []).append(
            {"name": p["partner_name"], "share_pct": float(p["share_pct"])}
        )
    for a in assets:
        a["partners"] = partner_map.get(a["id"], [])
        a["total_value"] = int(a["total_value"])
        a["purchase_date"] = str(a["purchase_date"])
    return assets


def load_asset_by_id(asset_id):
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM assets WHERE id = %s", (asset_id,))
            a = dict(cur.fetchone())
            cur.execute(
                "SELECT partner_name, share_pct FROM asset_partners WHERE asset_id = %s ORDER BY id",
                (asset_id,),
            )
            a["partners"] = [
                {"name": row["partner_name"], "share_pct": float(row["share_pct"])}
                for row in cur.fetchall()
            ]
    a["total_value"] = int(a["total_value"])
    a["purchase_date"] = str(a["purchase_date"])
    return a


def add_asset(name, category, location, total_value, purchase_date, status, partners):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO assets (name, category, location, total_value, purchase_date, status)
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (name, category, location, int(total_value), purchase_date, status),
            )
            asset_id = cur.fetchone()[0]
            psycopg2.extras.execute_batch(
                cur,
                "INSERT INTO asset_partners (asset_id, partner_name, share_pct) VALUES (%s, %s, %s)",
                [(asset_id, p["name"], p["share_pct"]) for p in partners],
            )
    return asset_id


def delete_asset(asset_id):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM assets WHERE id = %s", (asset_id,))


def update_asset_status(asset_id, status):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("UPDATE assets SET status = %s WHERE id = %s", (status, asset_id))


def update_asset(asset_id, name, category, location, total_value, purchase_date, status, partners):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE assets
                SET name = %s, category = %s, location = %s,
                    total_value = %s, purchase_date = %s, status = %s
                WHERE id = %s
                """,
                (name, category, location, int(total_value), purchase_date, status, asset_id),
            )
            cur.execute("DELETE FROM asset_partners WHERE asset_id = %s", (asset_id,))
            psycopg2.extras.execute_batch(
                cur,
                "INSERT INTO asset_partners (asset_id, partner_name, share_pct) VALUES (%s, %s, %s)",
                [(asset_id, p["name"], p["share_pct"]) for p in partners],
            )


# ── Valuations ────────────────────────────────────────────────────────────────

def load_all_valuations():
    """Return all valuation rows joined with asset name, ordered by date."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                SELECT v.id, v.asset_id, a.name AS asset_name, a.category,
                       v.valuation_date, v.value, v.notes
                FROM asset_valuations v
                JOIN assets a ON a.id = v.asset_id
                ORDER BY v.valuation_date, a.name
                """
            )
            rows = [dict(r) for r in cur.fetchall()]
    for r in rows:
        r["value"] = int(r["value"])
        r["valuation_date"] = str(r["valuation_date"])
    return rows


def load_valuations_for_asset(asset_id):
    """Return valuation history for a single asset, ordered by date."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                SELECT id, valuation_date, value, notes
                FROM asset_valuations
                WHERE asset_id = %s
                ORDER BY valuation_date
                """,
                (asset_id,),
            )
            rows = [dict(r) for r in cur.fetchall()]
    for r in rows:
        r["value"] = int(r["value"])
        r["valuation_date"] = str(r["valuation_date"])
    return rows


def add_valuation(asset_id, valuation_date, value, notes=""):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO asset_valuations (asset_id, valuation_date, value, notes)
                VALUES (%s, %s, %s, %s)
                """,
                (asset_id, valuation_date, int(value), notes),
            )


def delete_valuation(valuation_id):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM asset_valuations WHERE id = %s", (valuation_id,))


# ── Authentication ───────────────────────────────────────────────────────────

def register_user(username, email, password):
    """Hash password with bcrypt and insert a new user. Returns user id."""
    pw_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s) RETURNING id",
                (username.strip().lower(), email.strip().lower(), pw_hash),
            )
            return cur.fetchone()[0]


def authenticate_user(username, password):
    """Return user dict on success, None on failure."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "SELECT id, username, email, password_hash FROM users WHERE username = %s",
                (username.strip().lower(),),
            )
            row = cur.fetchone()
    if row is None:
        return None
    if bcrypt.checkpw(password.encode("utf-8"), row["password_hash"].encode("utf-8")):
        return {"id": row["id"], "username": row["username"], "email": row["email"]}
    return None


def username_exists(username):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM users WHERE username = %s", (username.strip().lower(),))
            return cur.fetchone() is not None


def email_exists(email):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM users WHERE email = %s", (email.strip().lower(),))
            return cur.fetchone() is not None


def get_user_by_username(username: str):
    """Return user dict (id, username, email) or None."""
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "SELECT id, username, email FROM users WHERE username = %s",
                (username.strip().lower(),),
            )
            row = cur.fetchone()
    return dict(row) if row else None


# ── Persistent sessions (30-day remember-me) ──────────────────────────────────

def _ensure_sessions_table():
    """Create user_sessions table if it does not exist."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS user_sessions (
                    id            SERIAL PRIMARY KEY,
                    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    session_token TEXT    NOT NULL UNIQUE,
                    expires_at    TIMESTAMPTZ NOT NULL,
                    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)


def create_session_token(user_id: int, days: int = 30) -> str:
    """Generate a persistent session token valid for `days` days and store it."""
    _ensure_sessions_table()
    token      = secrets.token_urlsafe(32)   # 256-bit random token
    expires_at = datetime.utcnow() + timedelta(days=days)
    with get_conn() as conn:
        with conn.cursor() as cur:
            # Purge expired tokens for this user to keep the table tidy
            cur.execute(
                "DELETE FROM user_sessions WHERE user_id = %s AND expires_at < NOW()",
                (user_id,),
            )
            cur.execute(
                "INSERT INTO user_sessions (user_id, session_token, expires_at) "
                "VALUES (%s, %s, %s)",
                (user_id, token, expires_at),
            )
    return token


def validate_session_token(token: str):
    """Return user dict if token exists and has not expired, else None."""
    _ensure_sessions_table()
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                SELECT u.id, u.username, u.email
                FROM   user_sessions s
                JOIN   users u ON u.id = s.user_id
                WHERE  s.session_token = %s
                  AND  s.expires_at    > NOW()
                """,
                (token,),
            )
            row = cur.fetchone()
    return dict(row) if row else None


def revoke_session_token(token: str) -> None:
    """Delete a specific session token (used on logout)."""
    _ensure_sessions_table()
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM user_sessions WHERE session_token = %s", (token,)
            )


# ── Password reset ────────────────────────────────────────────────────────────

def _ensure_reset_tokens_table():
    """Create the password_reset_tokens table if it doesn't exist yet."""
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS password_reset_tokens (
                    id         SERIAL PRIMARY KEY,
                    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    token      TEXT    NOT NULL UNIQUE,
                    expires_at TIMESTAMPTZ NOT NULL,
                    used       BOOLEAN NOT NULL DEFAULT FALSE,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)


def create_reset_token(identifier: str):
    """
    Look up a user by username OR email (case-insensitive).
    Invalidates any prior unused tokens for that user, then issues a new one.
    Returns (token_str, username) on success, or None if the user doesn't exist.
    The token is a 32-character URL-safe string and expires in 1 hour.
    """
    _ensure_reset_tokens_table()
    identifier = identifier.strip().lower()

    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "SELECT id, username FROM users WHERE username = %s OR email = %s",
                (identifier, identifier),
            )
            row = cur.fetchone()

    if row is None:
        return None

    token      = secrets.token_urlsafe(24)          # ~32-char random string
    expires_at = datetime.utcnow() + timedelta(hours=1)

    with get_conn() as conn:
        with conn.cursor() as cur:
            # Invalidate any existing unused tokens so only one is ever live
            cur.execute(
                "UPDATE password_reset_tokens SET used = TRUE "
                "WHERE user_id = %s AND used = FALSE",
                (row["id"],),
            )
            cur.execute(
                "INSERT INTO password_reset_tokens (user_id, token, expires_at) "
                "VALUES (%s, %s, %s)",
                (row["id"], token, expires_at),
            )

    return (token, row["username"])


def verify_reset_token(token: str):
    """
    Return the user dict if the token is valid, unused, and not expired.
    Returns None otherwise.
    """
    _ensure_reset_tokens_table()
    with get_conn() as conn:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """
                SELECT u.id, u.username, u.email
                FROM   password_reset_tokens t
                JOIN   users u ON u.id = t.user_id
                WHERE  t.token      = %s
                  AND  t.used       = FALSE
                  AND  t.expires_at > NOW()
                """,
                (token,),
            )
            row = cur.fetchone()
    return dict(row) if row else None


def consume_reset_token(token: str, new_password: str) -> bool:
    """
    Verify the token, update the user's password, and mark the token as used.
    Returns True on success, False if the token is invalid/expired/already used.
    """
    user = verify_reset_token(token)
    if user is None:
        return False

    pw_hash = bcrypt.hashpw(new_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE users SET password_hash = %s WHERE id = %s",
                (pw_hash, user["id"]),
            )
            cur.execute(
                "UPDATE password_reset_tokens SET used = TRUE WHERE token = %s",
                (token,),
            )
    return True


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_sawastik_share(asset):
    for p in asset["partners"]:
        if p["name"] == "Sawastik":
            return p["share_pct"]
    return 0.0


def get_sawastik_value(asset):
    return asset["total_value"] * get_sawastik_share(asset) / 100
