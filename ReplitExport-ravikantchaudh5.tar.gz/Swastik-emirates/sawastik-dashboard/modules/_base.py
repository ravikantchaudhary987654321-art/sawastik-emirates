"""
BaseModule — contract and documentation for all page modules.

Every page module (e.g. modules/sawastik_emirates/dashboard.py) must:

  1. Define a top-level  render(ctx: dict) -> None  function.
  2. Define module-level metadata constants PAGE_TITLE and PAGE_ICON
     (used by main.py to set the browser tab title on the active page).

──────────────────────────────────────────────────────────────────────────────
ctx  dictionary keys
──────────────────────────────────────────────────────────────────────────────
Key                 Type                Description
───                 ────                ───────────
assets              list[dict]          Raw asset rows from PostgreSQL
valuations          list[dict]          Raw valuation rows (joined with asset name/category)
df                  pd.DataFrame        Flat asset DataFrame (build_df helper)
vdf                 pd.DataFrame        Valuation DataFrame  (build_val_df helper)
get_assets          callable            @st.cache_data loader — call .clear() after mutations
get_valuations      callable            @st.cache_data loader — call .clear() after mutations
username            str                 Currently logged-in username

──────────────────────────────────────────────────────────────────────────────
Minimal module template  (copy this to your new module file)
──────────────────────────────────────────────────────────────────────────────

    import streamlit as st

    PAGE_TITLE = "My Page"
    PAGE_ICON  = "🗂️"


    def render(ctx: dict) -> None:
        assets     = ctx["assets"]
        df         = ctx["df"]
        get_assets = ctx["get_assets"]

        st.title(f"{PAGE_ICON} {PAGE_TITLE}")
        st.divider()
        st.write("Hello from my new module!")

──────────────────────────────────────────────────────────────────────────────
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class PageModule(Protocol):
    """Structural protocol — a module satisfies this if it has render()."""

    PAGE_TITLE: str
    PAGE_ICON: str

    def render(self, ctx: dict) -> None: ...
