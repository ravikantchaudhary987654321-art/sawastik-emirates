"""
Sample page — starting point for any new business unit page.

Copy this file into  modules/<your_unit_id>/  and rename it to match
the page id you declare in config.py.  Then implement render().
"""

import streamlit as st

PAGE_TITLE = "Sample Page"
PAGE_ICON  = "🗂️"


def render(ctx: dict) -> None:
    """
    Render this page.

    ctx keys available:
        assets, valuations, df, vdf,
        get_assets, get_valuations, username
    """
    st.title(f"{PAGE_ICON} {PAGE_TITLE}")
    st.divider()

    username = ctx.get("username", "")
    st.markdown(f"Welcome, **{username}**! This is a sample page from the `_template` module.")
    st.info(
        "Replace the contents of this `render()` function with your own Streamlit UI. "
        "Use `ctx['assets']`, `ctx['df']`, etc. to access shared portfolio data."
    )

    st.subheader("Available context keys")
    st.json({k: str(type(v).__name__) for k, v in ctx.items()})
