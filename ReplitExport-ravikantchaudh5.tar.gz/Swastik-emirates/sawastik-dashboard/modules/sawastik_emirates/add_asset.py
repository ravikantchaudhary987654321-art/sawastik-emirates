import streamlit as st

PAGE_TITLE = "Add Asset"
PAGE_ICON  = "➕"


def render(ctx: dict) -> None:
    get_assets     = ctx["get_assets"]
    get_valuations = ctx["get_valuations"]

    from data import add_asset, add_valuation

    st.title("➕ Add New Asset")
    st.divider()

    with st.form("add_asset_form"):
        c1, c2 = st.columns(2)
        with c1:
            name     = st.text_input("Asset Name *")
            category = st.selectbox("Category *",
                ["Commercial", "Residential", "Retail", "Industrial", "Mixed-Use", "Other"])
            location = st.text_input("Location *")
        with c2:
            total_value   = st.number_input("Total Value (AED) *", min_value=0, step=100000)
            purchase_date = st.date_input("Purchase Date *")
            status        = st.selectbox("Status *", ["Active", "Under Review", "Sold", "On Hold"])

        st.subheader("Partner Shareholding")
        st.caption("Add at least one partner. Shares must sum to 100%.")
        num_partners = st.number_input("Number of Partners", min_value=1, max_value=6, value=2, step=1)
        partners = []
        cols = st.columns(2)
        for i in range(int(num_partners)):
            with cols[i % 2]:
                p_name  = st.text_input(f"Partner {i+1} Name", key=f"pname_{i}")
                p_share = st.number_input(f"Partner {i+1} Share (%)",
                                          min_value=0.0, max_value=100.0, step=0.5, key=f"pshare_{i}")
                if p_name:
                    partners.append({"name": p_name, "share_pct": p_share})

        submitted = st.form_submit_button("💾 Save Asset", type="primary", use_container_width=True)

    if submitted:
        errors = []
        if not name:
            errors.append("Asset name is required.")
        if not location:
            errors.append("Location is required.")
        if total_value <= 0:
            errors.append("Total value must be greater than 0.")
        if not partners:
            errors.append("Add at least one partner.")
        else:
            total_pct = sum(p["share_pct"] for p in partners)
            if abs(total_pct - 100) > 0.5:
                errors.append(f"Partner shares must sum to 100% (currently {total_pct:.1f}%).")
        for e in errors:
            st.error(e)
        if not errors:
            new_id = add_asset(name=name, category=category, location=location,
                               total_value=int(total_value), purchase_date=str(purchase_date),
                               status=status, partners=partners)
            add_valuation(new_id, str(purchase_date), int(total_value),
                          "Initial valuation on asset creation")
            get_assets.clear()
            get_valuations.clear()
            st.success(f"✅ Asset '{name}' saved to database!")
            st.balloons()
