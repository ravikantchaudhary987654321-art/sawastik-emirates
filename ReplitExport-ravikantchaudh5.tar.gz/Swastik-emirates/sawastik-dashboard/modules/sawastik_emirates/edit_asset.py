import datetime
import streamlit as st

PAGE_TITLE = "Edit Asset"
PAGE_ICON  = "✏️"

CATEGORIES = ["Commercial", "Residential", "Retail", "Industrial", "Mixed-Use", "Other"]
STATUSES   = ["Active", "Under Review", "Sold", "On Hold"]


def render(ctx: dict) -> None:
    assets     = ctx["assets"]
    get_assets = ctx["get_assets"]

    from data import update_asset

    st.title("✏️ Edit Asset")
    st.divider()

    asset_options = {a["name"]: a for a in assets}
    selected_name = st.selectbox("Select asset to edit", list(asset_options.keys()))
    sel           = asset_options[selected_name]
    st.caption(f"Editing asset ID {sel['id']} — changes are saved directly to the database.")
    st.divider()

    cat_index    = CATEGORIES.index(sel["category"]) if sel["category"] in CATEGORIES else 0
    status_index = STATUSES.index(sel["status"])     if sel["status"]   in STATUSES   else 0

    try:
        existing_date = datetime.date.fromisoformat(str(sel["purchase_date"])[:10])
    except ValueError:
        existing_date = datetime.date.today()

    with st.form("edit_asset_form"):
        c1, c2 = st.columns(2)
        with c1:
            e_name     = st.text_input("Asset Name *",     value=sel["name"])
            e_category = st.selectbox("Category *",        CATEGORIES, index=cat_index)
            e_location = st.text_input("Location *",       value=sel["location"])
        with c2:
            e_value  = st.number_input("Total Value (AED) *", min_value=0, step=100000,
                                       value=int(sel["total_value"]))
            e_date   = st.date_input("Purchase Date *", value=existing_date)
            e_status = st.selectbox("Status *", STATUSES, index=status_index)

        st.subheader("Partner Shareholding")
        st.caption("Shares must sum to 100%. Existing partners are pre-filled.")
        existing_partners = sel["partners"]
        num_partners = st.number_input("Number of Partners", min_value=1, max_value=6,
                                       value=max(len(existing_partners), 1), step=1)
        partners = []
        cols = st.columns(2)
        for i in range(int(num_partners)):
            existing = existing_partners[i] if i < len(existing_partners) else {}
            with cols[i % 2]:
                p_name  = st.text_input(f"Partner {i+1} Name",
                                        value=existing.get("name", ""), key=f"ep_name_{i}")
                p_share = st.number_input(f"Partner {i+1} Share (%)",
                                          min_value=0.0, max_value=100.0, step=0.5,
                                          value=float(existing.get("share_pct", 0.0)),
                                          key=f"ep_share_{i}")
                if p_name:
                    partners.append({"name": p_name, "share_pct": p_share})

        total_pct_preview = sum(p["share_pct"] for p in partners)
        if partners:
            color = "green" if abs(total_pct_preview - 100) <= 0.5 else "red"
            st.markdown(f"**Share total:** :{color}[{total_pct_preview:.1f}%]")

        save_btn = st.form_submit_button("💾 Save Changes", type="primary", use_container_width=True)

    if save_btn:
        errors = []
        if not e_name:      errors.append("Asset name is required.")
        if not e_location:  errors.append("Location is required.")
        if e_value <= 0:    errors.append("Total value must be greater than 0.")
        if not partners:
            errors.append("Add at least one partner.")
        else:
            total_pct = sum(p["share_pct"] for p in partners)
            if abs(total_pct - 100) > 0.5:
                errors.append(f"Partner shares must sum to 100% (currently {total_pct:.1f}%).")
        for e in errors:
            st.error(e)
        if not errors:
            update_asset(asset_id=sel["id"], name=e_name, category=e_category,
                         location=e_location, total_value=int(e_value),
                         purchase_date=str(e_date), status=e_status, partners=partners)
            get_assets.clear()
            st.success(f"✅ '{e_name}' updated successfully in the database.")
            st.rerun()
