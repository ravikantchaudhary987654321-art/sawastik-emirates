import streamlit as st
import pandas as pd
import plotly.express as px

PAGE_TITLE = "Partner View"
PAGE_ICON  = "👥"


def render(ctx: dict) -> None:
    assets = ctx["assets"]

    st.title("👥 Partner View")
    st.divider()

    partner_rows = []
    for a in assets:
        for p in a["partners"]:
            partner_rows.append({
                "Partner": p["name"], "Asset": a["name"], "Category": a["category"],
                "Asset Total (AED)": a["total_value"], "Share (%)": p["share_pct"],
                "Value (AED)": a["total_value"] * p["share_pct"] / 100,
            })
    partner_df      = pd.DataFrame(partner_rows)
    all_partners    = sorted(partner_df["Partner"].unique().tolist())
    selected_partner= st.selectbox("Select Partner", all_partners)
    p_df            = partner_df[partner_df["Partner"] == selected_partner]

    c1, c2, c3 = st.columns(3)
    c1.metric("Total Assets",        len(p_df))
    c2.metric("Total Invested (AED)", f"AED {p_df['Value (AED)'].sum():,.0f}")
    c3.metric("Avg Share",           f"{p_df['Share (%)'].mean():.1f}%")

    st.divider()
    col1, col2 = st.columns(2)
    with col1:
        fig = px.bar(p_df.sort_values("Value (AED)", ascending=True),
                     x="Value (AED)", y="Asset", orientation="h", color="Category",
                     color_discrete_sequence=px.colors.qualitative.Set2,
                     title=f"{selected_partner}'s Investments by Asset")
        fig.update_layout(height=300, margin=dict(t=40, b=10, l=10, r=10), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        cat_sum = p_df.groupby("Category")["Value (AED)"].sum().reset_index()
        fig2 = px.pie(cat_sum, names="Category", values="Value (AED)", hole=0.4,
                      title=f"{selected_partner}'s Portfolio by Category",
                      color_discrete_sequence=px.colors.qualitative.Pastel)
        fig2.update_layout(height=300, margin=dict(t=40, b=10, l=10, r=10))
        st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Asset Breakdown")
    st.dataframe(
        p_df[["Asset", "Category", "Asset Total (AED)", "Share (%)", "Value (AED)"]].style.format({
            "Asset Total (AED)": "AED {:,.0f}", "Value (AED)": "AED {:,.0f}", "Share (%)": "{:.0f}%",
        }),
        use_container_width=True, hide_index=True,
    )

    st.divider()
    st.subheader("All Partners Summary")
    summary = (
        partner_df.groupby("Partner")
        .agg(Assets=("Asset", "count"), Total_Value=("Value (AED)", "sum"),
             Avg_Share=("Share (%)", "mean"))
        .reset_index()
        .rename(columns={"Total_Value": "Total Value (AED)", "Avg_Share": "Avg Share (%)"})
        .sort_values("Total Value (AED)", ascending=False)
    )
    st.dataframe(
        summary.style.format({"Total Value (AED)": "AED {:,.0f}", "Avg Share (%)": "{:.1f}%"}),
        use_container_width=True, hide_index=True,
    )
