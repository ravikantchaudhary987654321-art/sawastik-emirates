import datetime
import streamlit as st
import plotly.express as px

PAGE_TITLE = "Valuation History"
PAGE_ICON  = "📅"


def render(ctx: dict) -> None:
    assets         = ctx["assets"]
    vdf            = ctx["vdf"]
    get_valuations = ctx["get_valuations"]

    from data import add_valuation, delete_valuation

    st.title("📅 Valuation History")
    st.caption("Track how each asset's value has changed over time.")
    st.divider()

    if vdf.empty:
        st.info("No valuation records found. Log your first entry below.")
    else:
        all_asset_names  = sorted(vdf["Asset"].unique().tolist())
        selected_assets  = st.multiselect("Select assets to compare (leave empty = show all)",
                                          all_asset_names, default=[])
        chart_df = vdf if not selected_assets else vdf[vdf["Asset"].isin(selected_assets)]

        st.subheader("Asset Value Trend Lines")
        fig_lines = px.line(chart_df.sort_values("Date"), x="Date", y="Value (AED)",
                            color="Asset", markers=True,
                            color_discrete_sequence=px.colors.qualitative.Set1)
        fig_lines.update_traces(line_width=2, marker_size=7)
        fig_lines.update_layout(height=400, margin=dict(t=10, b=10, l=10, r=10),
                                yaxis_tickformat=",.0f",
                                legend=dict(orientation="h", yanchor="bottom", y=1.02,
                                            xanchor="right", x=1))
        st.plotly_chart(fig_lines, use_container_width=True)

        st.subheader("Appreciation Since First Record")
        import pandas as pd
        gain_rows = []
        for asset_name, grp in vdf.groupby("Asset"):
            grp_sorted = grp.sort_values("Date")
            fv, lv = grp_sorted["Value (AED)"].iloc[0], grp_sorted["Value (AED)"].iloc[-1]
            change_pct = ((lv - fv) / fv * 100) if fv else 0
            gain_rows.append({
                "Asset": asset_name,
                "First Value (AED)": fv, "Latest Value (AED)": lv,
                "Gain (AED)": lv - fv, "Gain (%)": change_pct,
                "From": str(grp_sorted["Date"].iloc[0].date()),
                "To":   str(grp_sorted["Date"].iloc[-1].date()),
            })
        gain_df  = pd.DataFrame(gain_rows).sort_values("Gain (%)", ascending=False)
        fig_gain = px.bar(gain_df, x="Asset", y="Gain (%)",
                          color="Gain (%)", color_continuous_scale=["#d73027", "#fee090", "#4dac26"],
                          text_auto=".1f")
        fig_gain.update_traces(texttemplate="%{text}%")
        fig_gain.update_layout(height=320, margin=dict(t=10, b=10, l=10, r=10),
                               coloraxis_showscale=False, xaxis_tickangle=-20)
        st.plotly_chart(fig_gain, use_container_width=True)
        st.dataframe(
            gain_df.style.format({
                "First Value (AED)": "AED {:,.0f}", "Latest Value (AED)": "AED {:,.0f}",
                "Gain (AED)": "AED {:,.0f}", "Gain (%)": "{:.1f}%",
            }),
            use_container_width=True, hide_index=True,
        )

    # ── Log a new valuation ───────────────────────────────────────────────────
    st.divider()
    st.subheader("Log a New Valuation")
    asset_name_map = {a["name"]: a["id"] for a in assets}
    with st.form("log_valuation_form"):
        lc1, lc2 = st.columns(2)
        with lc1:
            lv_asset = st.selectbox("Asset *", list(asset_name_map.keys()))
            lv_date  = st.date_input("Valuation Date *", value=datetime.date.today())
        with lc2:
            lv_value = st.number_input("Value (AED) *", min_value=0, step=100000)
            lv_notes = st.text_input("Notes (optional)", placeholder="e.g. Q2 2025 appraisal")
        log_btn = st.form_submit_button("📌 Log Valuation", type="primary", use_container_width=True)

    if log_btn:
        if lv_value <= 0:
            st.error("Value must be greater than 0.")
        else:
            add_valuation(asset_id=asset_name_map[lv_asset],
                          valuation_date=str(lv_date), value=int(lv_value), notes=lv_notes)
            get_valuations.clear()
            st.success(f"✅ Valuation logged for '{lv_asset}' on {lv_date}.")
            st.rerun()

    # ── Full history table ────────────────────────────────────────────────────
    if not vdf.empty:
        st.divider()
        st.subheader("Full Valuation History")
        filter_asset = st.selectbox("Filter by asset",
                                    ["All"] + sorted(vdf["Asset"].unique().tolist()),
                                    key="hist_filter")
        history_df   = vdf if filter_asset == "All" else vdf[vdf["Asset"] == filter_asset]
        history_df   = history_df.sort_values(["Asset", "Date"], ascending=[True, False])
        display_cols = [c for c in ["id", "Asset", "Category", "Date", "Value (AED)", "notes"]
                        if c in history_df.columns]
        show_df = history_df[display_cols].copy()
        show_df["Date"] = show_df["Date"].dt.date
        st.dataframe(
            show_df.rename(columns={"id": "ID", "notes": "Notes"})
            .style.format({"Value (AED)": "AED {:,.0f}"}),
            use_container_width=True, hide_index=True,
        )
        with st.expander("🗑️ Delete a valuation entry"):
            del_id = st.number_input("Enter Valuation ID to delete", min_value=1, step=1)
            if st.button("Delete Entry", type="primary"):
                delete_valuation(int(del_id))
                get_valuations.clear()
                st.success(f"Valuation ID {del_id} deleted.")
                st.rerun()
