import streamlit as st
import pandas as pd
import plotly.express as px

PAGE_TITLE = "Asset Portfolio"
PAGE_ICON  = "🏢"


def render(ctx: dict) -> None:
    assets        = ctx["assets"]
    df            = ctx["df"]
    get_assets    = ctx["get_assets"]
    get_valuations= ctx["get_valuations"]

    from data import delete_asset

    st.title("🏢 Asset Portfolio")
    st.divider()

    col1, col2, col3 = st.columns(3)
    with col1:
        cats       = ["All"] + sorted(df["Category"].unique().tolist())
        cat_filter = st.selectbox("Filter by Category", cats)
    with col2:
        statuses      = ["All"] + sorted(df["Status"].unique().tolist())
        status_filter = st.selectbox("Filter by Status", statuses)
    with col3:
        search = st.text_input("Search by Name / Location")

    filtered = df.copy()
    if cat_filter != "All":
        filtered = filtered[filtered["Category"] == cat_filter]
    if status_filter != "All":
        filtered = filtered[filtered["Status"] == status_filter]
    if search:
        mask = (filtered["Asset Name"].str.contains(search, case=False)
                | filtered["Location"].str.contains(search, case=False))
        filtered = filtered[mask]

    st.caption(f"Showing {len(filtered)} of {len(df)} assets")
    st.dataframe(
        filtered[["Asset Name", "Category", "Location", "Total Value (AED)",
                  "Sawastik Share (%)", "Sawastik Value (AED)", "Status", "Purchase Date"]
        ].style.format({
            "Total Value (AED)":    "AED {:,.0f}",
            "Sawastik Value (AED)": "AED {:,.0f}",
            "Sawastik Share (%)":   "{:.0f}%",
        }),
        use_container_width=True, hide_index=True,
    )

    st.divider()
    st.subheader("Asset Details")
    selected_name  = st.selectbox("Select an asset to view partners", df["Asset Name"].tolist())
    selected_asset = next(a for a in assets if a["name"] == selected_name)

    c1, c2 = st.columns([1, 2])
    with c1:
        st.markdown(f"**Category:** {selected_asset['category']}")
        st.markdown(f"**Location:** {selected_asset['location']}")
        st.markdown(f"**Total Value:** AED {selected_asset['total_value']:,}")
        st.markdown(f"**Status:** {selected_asset['status']}")
        st.markdown(f"**Purchase Date:** {selected_asset['purchase_date']}")
    with c2:
        partners_df = pd.DataFrame(selected_asset["partners"])
        partners_df["Value (AED)"] = partners_df["share_pct"] / 100 * selected_asset["total_value"]
        fig = px.pie(partners_df, names="name", values="share_pct",
                     title="Partner Share Distribution", hole=0.35,
                     color_discrete_sequence=px.colors.qualitative.Pastel)
        fig.update_layout(margin=dict(t=40, b=10, l=10, r=10), height=260)
        st.plotly_chart(fig, use_container_width=True)

    st.dataframe(
        partners_df.rename(columns={"name": "Partner", "share_pct": "Share (%)"})
        .style.format({"Share (%)": "{:.0f}%", "Value (AED)": "AED {:,.0f}"}),
        use_container_width=True, hide_index=True,
    )

    st.divider()
    with st.expander("⚠️ Delete this asset"):
        if st.button(f"Delete '{selected_name}'", type="primary"):
            delete_asset(selected_asset["id"])
            get_assets.clear()
            get_valuations.clear()
            st.success(f"'{selected_name}' deleted from database.")
            st.rerun()
