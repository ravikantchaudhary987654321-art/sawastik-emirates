import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

PAGE_TITLE = "Analytics"
PAGE_ICON  = "📈"


def render(ctx: dict) -> None:
    df  = ctx["df"]
    vdf = ctx["vdf"]

    st.title("📈 Analytics")
    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Asset Value by Category")
        cat_df = df.groupby("Category").agg(
            Assets=("Asset Name", "count"),
            Total_Value=("Total Value (AED)", "sum"),
            Sawastik_Value=("Sawastik Value (AED)", "sum"),
        ).reset_index()
        fig = px.bar(cat_df, x="Category", y=["Total_Value", "Sawastik_Value"], barmode="group",
                     labels={"value": "Value (AED)", "variable": ""},
                     color_discrete_map={"Total_Value": "#4C78A8", "Sawastik_Value": "#F58518"})
        fig.update_layout(height=320, margin=dict(t=10, b=10, l=10, r=10))
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Sawastik Share % per Asset")
        fig2 = px.bar(df.sort_values("Sawastik Share (%)", ascending=False),
                      x="Asset Name", y="Sawastik Share (%)", color="Category",
                      color_discrete_sequence=px.colors.qualitative.Set2, text_auto=".0f")
        fig2.update_traces(texttemplate="%{text}%")
        fig2.update_layout(height=320, margin=dict(t=10, b=10, l=10, r=10),
                           xaxis_tickangle=-30, showlegend=False)
        st.plotly_chart(fig2, use_container_width=True)

    st.divider()
    st.subheader("Portfolio Value Waterfall")
    fig3 = go.Figure(go.Waterfall(
        name="Portfolio", orientation="v",
        measure=["relative"] * len(df) + ["total"],
        x=df["Asset Name"].tolist() + ["Total"],
        y=df["Total Value (AED)"].tolist() + [0],
        connector={"line": {"color": "rgb(63, 63, 63)"}},
        increasing={"marker": {"color": "#4C78A8"}},
        totals={"marker": {"color": "#F58518"}},
    ))
    fig3.update_layout(height=360, margin=dict(t=10, b=10, l=10, r=10), showlegend=False)
    st.plotly_chart(fig3, use_container_width=True)

    if not vdf.empty:
        st.divider()
        st.subheader("Per-Asset Value History")
        st.caption("Line chart showing each asset's appraised value across all recorded dates.")
        fig_hist = px.line(vdf.sort_values("Date"), x="Date", y="Value (AED)", color="Asset",
                           facet_col="Asset", facet_col_wrap=3, markers=True,
                           color_discrete_sequence=px.colors.qualitative.Set1)
        fig_hist.update_traces(line_width=2, marker_size=5)
        fig_hist.update_layout(height=500, margin=dict(t=40, b=10, l=10, r=10), showlegend=False)
        fig_hist.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1]))
        fig_hist.update_yaxes(tickformat=",.0f", matches=None)
        st.plotly_chart(fig_hist, use_container_width=True)

    st.divider()
    st.subheader("Status Distribution")
    status_df = df["Status"].value_counts().reset_index()
    status_df.columns = ["Status", "Count"]
    fig4 = px.pie(status_df, names="Status", values="Count", hole=0.4,
                  color_discrete_sequence=px.colors.qualitative.Safe)
    fig4.update_layout(height=280, margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig4, use_container_width=True)
