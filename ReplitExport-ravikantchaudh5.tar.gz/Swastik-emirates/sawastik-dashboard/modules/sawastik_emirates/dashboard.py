import datetime
import streamlit as st
import pandas as pd
import plotly.express as px
from report import generate_report

PAGE_TITLE = "Dashboard"
PAGE_ICON  = "📊"


def render(ctx: dict) -> None:
    assets         = ctx["assets"]
    valuations     = ctx["valuations"]
    df             = ctx["df"]
    vdf            = ctx["vdf"]
    username       = ctx.get("username", "")

    st.title("📊 Dashboard Overview")
    st.caption("Sawastik Emirates – Real-time asset & finance summary")
    st.divider()

    # ── KPI calculations ─────────────────────────────────────────────────────
    total_portfolio = df["Total Value (AED)"].sum()
    sawastik_total  = df["Sawastik Value (AED)"].sum()
    active_assets   = len(df[df["Status"] == "Active"])
    avg_share       = df["Sawastik Share (%)"].mean()

    if not vdf.empty:
        first_vals       = vdf.sort_values("Date").groupby("asset_id")["Value (AED)"].first()
        total_investment = int(first_vals.sum())
    else:
        total_investment = int(total_portfolio)

    net_gain     = int(total_portfolio) - total_investment
    net_gain_pct = (net_gain / total_investment * 100) if total_investment else 0
    gain_delta   = f"{'+' if net_gain >= 0 else ''}{net_gain_pct:.1f}% vs initial investment"

    # ── KPI Cards ─────────────────────────────────────────────────────────────
    st.markdown("### 📌 Key Performance Indicators")
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("🏦 Total Portfolio Value", f"AED {total_portfolio:,.0f}",
              help="Sum of current values across all assets")
    k2.metric("💰 Total Investment",      f"AED {total_investment:,.0f}",
              help="Sum of each asset's earliest recorded valuation")
    k3.metric("📈 Net Gain",              f"AED {net_gain:,.0f}",
              delta=gain_delta, delta_color="normal",
              help="Current portfolio value minus total investment")
    k4.metric("🏢 Active Assets",         f"{active_assets} / {len(assets)}",
              help="Assets with status = Active")
    k5.metric("🤝 Avg Sawastik Share",    f"{avg_share:.1f}%",
              help="Average Sawastik ownership percentage across all assets")

    st.divider()

    # ── Charts ────────────────────────────────────────────────────────────────
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Portfolio by Category")
        cat_df  = df.groupby("Category")["Total Value (AED)"].sum().reset_index()
        fig_pie = px.pie(cat_df, names="Category", values="Total Value (AED)",
                         hole=0.4, color_discrete_sequence=px.colors.qualitative.Set2)
        fig_pie.update_layout(margin=dict(t=10, b=10, l=10, r=10), height=320)
        st.plotly_chart(fig_pie, use_container_width=True)

    with col2:
        st.subheader("Sawastik Share per Asset")
        fig_bar = px.bar(
            df.sort_values("Sawastik Value (AED)", ascending=False),
            x="Asset Name", y="Sawastik Value (AED)", color="Category",
            color_discrete_sequence=px.colors.qualitative.Set2, text_auto=".2s",
        )
        fig_bar.update_layout(margin=dict(t=10, b=10, l=10, r=10), height=320,
                              xaxis_tickangle=-30, showlegend=False)
        st.plotly_chart(fig_bar, use_container_width=True)

    # ── Portfolio Trend with Date Range Filter ────────────────────────────────
    st.divider()
    st.subheader("📅 Portfolio Value Trend")

    if not vdf.empty:
        portfolio_trend_full = vdf.groupby("Date")["Value (AED)"].sum().reset_index()
        today = pd.Timestamp(datetime.date.today())
        if portfolio_trend_full["Date"].max() < today:
            portfolio_trend_full = pd.concat([
                portfolio_trend_full,
                pd.DataFrame([{"Date": today, "Value (AED)": int(total_portfolio)}])
            ], ignore_index=True)
        portfolio_trend_full = portfolio_trend_full.sort_values("Date")

        min_date = portfolio_trend_full["Date"].min().date()
        max_date = portfolio_trend_full["Date"].max().date()

        dr1, dr2, dr3 = st.columns([2, 2, 1])
        with dr1:
            range_start = st.date_input("From", value=min_date,
                                        min_value=min_date, max_value=max_date, key="dr_start")
        with dr2:
            range_end = st.date_input("To", value=max_date,
                                      min_value=min_date, max_value=max_date, key="dr_end")
        with dr3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Reset", use_container_width=True):
                range_start, range_end = min_date, max_date

        if range_start > range_end:
            st.warning("'From' date must be before 'To' date.")
            portfolio_trend = portfolio_trend_full
        else:
            mask = ((portfolio_trend_full["Date"].dt.date >= range_start) &
                    (portfolio_trend_full["Date"].dt.date <= range_end))
            portfolio_trend = portfolio_trend_full[mask]

        if portfolio_trend.empty:
            st.info("No valuation data in the selected date range.")
        else:
            fig_trend = px.line(portfolio_trend, x="Date", y="Value (AED)", markers=True,
                                labels={"Value (AED)": "Total Portfolio Value (AED)"},
                                color_discrete_sequence=["#4C78A8"])
            fig_trend.update_traces(line_width=2.5, marker_size=7)
            fig_trend.update_layout(height=320, margin=dict(t=10, b=10, l=10, r=10),
                                    yaxis_tickformat=",.0f")
            st.plotly_chart(fig_trend, use_container_width=True)

            sv  = portfolio_trend["Value (AED)"].iloc[0]
            ev  = portfolio_trend["Value (AED)"].iloc[-1]
            pg  = ev - sv
            pgp = (pg / sv * 100) if sv else 0
            g1, g2, g3 = st.columns(3)
            g1.metric("Period Start Value", f"AED {sv:,.0f}",
                      help=f"Value on {portfolio_trend['Date'].iloc[0].date()}")
            g2.metric("Period End Value",   f"AED {ev:,.0f}",
                      help=f"Value on {portfolio_trend['Date'].iloc[-1].date()}")
            g3.metric("Period Gain",        f"AED {pg:,.0f}",
                      delta=f"{'+' if pg >= 0 else ''}{pgp:.1f}%", delta_color="normal")
    else:
        st.info("No valuation history yet. Add entries from the 📅 Valuation History page.")

    # ── Asset Growth Table ────────────────────────────────────────────────────
    st.divider()
    st.subheader("📊 Asset Growth Overview")
    st.caption("Assets with negative growth are highlighted in red.")

    if not vdf.empty:
        growth_rows = []
        for a in assets:
            a_vdf = vdf[vdf["asset_id"] == a["id"]].sort_values("Date")
            if len(a_vdf) >= 2:
                fv, lv = int(a_vdf["Value (AED)"].iloc[0]), int(a_vdf["Value (AED)"].iloc[-1])
                fd, ld = a_vdf["Date"].iloc[0].date(), a_vdf["Date"].iloc[-1].date()
                chg, chg_pct = lv - fv, ((lv - fv) / fv * 100) if fv else 0
            elif len(a_vdf) == 1:
                fv = lv = int(a_vdf["Value (AED)"].iloc[0])
                fd = ld = a_vdf["Date"].iloc[0].date()
                chg, chg_pct = 0, 0.0
            else:
                fv = lv = a["total_value"]
                fd = ld = a["purchase_date"]
                chg, chg_pct = 0, 0.0
            growth_rows.append({
                "Asset": a["name"], "Category": a["category"], "Status": a["status"],
                "Initial Value (AED)": fv, "Current Value (AED)": lv,
                "Gain (AED)": chg, "Growth (%)": round(chg_pct, 2),
                "From": str(fd), "To": str(ld),
            })

        growth_df = pd.DataFrame(growth_rows).sort_values("Growth (%)", ascending=True)

        def _style(row):
            if row["Growth (%)"] < 0:
                return ["color: #d62728; font-weight: bold"] * len(row)
            if row["Growth (%)"] > 0:
                return ["color: #2ca02c; font-weight: bold"] * len(row)
            return [""] * len(row)

        st.dataframe(
            growth_df.style.apply(_style, axis=1).format({
                "Initial Value (AED)": "AED {:,.0f}", "Current Value (AED)": "AED {:,.0f}",
                "Gain (AED)": "AED {:,.0f}", "Growth (%)": "{:+.2f}%",
            }),
            use_container_width=True, hide_index=True,
        )
        neg = [r["Asset"] for r in growth_rows if r["Growth (%)"] < 0]
        if neg:
            st.warning(f"⚠️ **{len(neg)} asset(s) showing negative growth:** {', '.join(neg)}")
        else:
            st.success("✅ All assets are showing positive or neutral growth.")
    else:
        st.dataframe(
            df[["Asset Name", "Category", "Status", "Total Value (AED)", "Sawastik Share (%)"]].style.format({
                "Total Value (AED)": "AED {:,.0f}", "Sawastik Share (%)": "{:.0f}%",
            }),
            use_container_width=True, hide_index=True,
        )
        st.info("Log valuations on the 📅 Valuation History page to track growth over time.")

    # ── Download Report ───────────────────────────────────────────────────────
    st.divider()
    st.subheader("📄 Download Portfolio Report")
    st.caption("Branded PDF: KPI summary, asset portfolio, growth analysis, partner breakdown, valuation history.")

    if st.button("⬇️ Generate PDF Report", type="primary"):
        with st.spinner("Building your report…"):
            try:
                pdf_bytes = generate_report(
                    assets=assets, valuations=valuations,
                    total_portfolio=int(total_portfolio), total_investment=total_investment,
                    net_gain=net_gain, net_gain_pct=net_gain_pct,
                    active_assets=active_assets, avg_share=avg_share,
                    generated_by=username,
                )
                today_label = datetime.date.today().strftime("%Y-%m-%d")
                st.download_button(
                    label="📥 Click here to download the PDF",
                    data=pdf_bytes,
                    file_name=f"sawastik_portfolio_report_{today_label}.pdf",
                    mime="application/pdf",
                    type="primary",
                )
                st.success("✅ Report ready — click the button above to save it.")
            except Exception as e:
                st.error(f"Failed to generate report: {e}")
