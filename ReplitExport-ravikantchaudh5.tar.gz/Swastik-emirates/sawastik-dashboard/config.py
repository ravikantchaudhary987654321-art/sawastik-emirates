"""
Business unit registry.

To add a new business unit:
  1. Create sawastik-dashboard/modules/<unit_id>/  with an __init__.py
  2. Add one Python file per page (each must expose  render(ctx) -> None)
  3. Add an entry to BUSINESS_UNITS below — no changes to main.py needed.
"""

BUSINESS_UNITS = [
    {
        "id": "sawastik_emirates",
        "name": "Sawastik Emirates",
        "icon": "🏗️",
        "description": "UAE Real Estate & Finance Manager",
        "pages": [
            {"id": "dashboard",         "title": "Dashboard",         "icon": "📊"},
            {"id": "portfolio",         "title": "Asset Portfolio",   "icon": "🏢"},
            {"id": "add_asset",         "title": "Add Asset",         "icon": "➕"},
            {"id": "edit_asset",        "title": "Edit Asset",        "icon": "✏️"},
            {"id": "valuation_history", "title": "Valuation History", "icon": "📅"},
            {"id": "partner_view",      "title": "Partner View",      "icon": "👥"},
            {"id": "analytics",         "title": "Analytics",         "icon": "📈"},
        ],
    },

    # ── Template for a new business unit ────────────────────────────────────
    # Uncomment and fill in to add Stocks, AI Ventures, etc.
    #
    # {
    #     "id": "stocks",
    #     "name": "Stocks & Equities",
    #     "icon": "📈",
    #     "description": "Global stock portfolio tracker",
    #     "pages": [
    #         {"id": "sample_page", "title": "Overview", "icon": "🗂️"},
    #     ],
    # },
]
