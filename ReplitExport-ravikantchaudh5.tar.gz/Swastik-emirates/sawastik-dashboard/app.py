import datetime
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from report import generate_report
from data import (
    load_assets,
    add_asset,
    delete_asset,
    update_asset,
    load_all_valuations,
    add_valuation,
    delete_valuation,
    get_sawastik_share,
    get_sawastik_value,
    register_user,
    authenticate_user,
    username_exists,
    email_exists,
)

st.set_page_config(
    page_title="Sawastik Emirates - Asset & Finance Manager",
    page_icon="🏗️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ════════════════════════════════════════════════════════════════════════════
# AUTH GATE — show login/signup before anything else
# ════════════════════════════════════════════════════════════════════════════
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = ""

if not st.session_state.logged_in:
    # Centre the auth card
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        st.markdown("## 🏗️ Sawastik Emirates")
        st.markdown("#### Asset & Finance Manager")
        st.divider()

        tab_login, tab_signup = st.tabs(["🔑 Login", "📝 Sign Up"])

        # ── Login tab ────────────────────────────────────────────────────────
        with tab_login:
            with st.form("login_form"):
                l_user = st.text_input("Username")
                l_pass = st.text_input("Password", type="password")
                login_btn = st.form_submit_button("Login", type="primary", use_container_width=True)

            if login_btn:
                if not l_user or not l_pass:
                    st.error("Please enter both username and password.")
                else:
                    user = authenticate_user(l_user, l_pass)
                    if user:
                        st.session_state.logged_in = True
                        st.session_state.username = user["username"]
                        st.rerun()
                    else:
                        st.error("Invalid username or password.")

        # ── Sign Up tab ──────────────────────────────────────────────────────
        with tab_signup:
            with st.form("signup_form"):
                s_user = st.text_input("Username")
                s_email = st.text_input("Email")
                s_pass = st.text_input("Password", type="password")
                s_pass2 = st.text_input("Confirm Password", type="password")
                signup_btn = st.form_submit_button("Create Account", type="primary", use_container_width=True)

            if signup_btn:
                errors = []
                if not s_user or not s_email or not s_pass:
                    errors.append("All fields are required.")
                elif len(s_user.strip()) < 3:
                    errors.append("Username must be at least 3 characters.")
                elif len(s_pass) < 8:
                    errors.append("Password must be at least 8 characters.")
                elif s_pass != s_pass2:
                    errors.append("Passwords do not match.")
                elif "@" not in s_email or "." not in s_email:
                    errors.append("Please enter a valid email address.")
                elif username_exists(s_user):
                    errors.append("That username is already taken.")
                elif email_exists(s_email):
                    errors.append("An account with that email already exists.")

                if errors:
                    for e in errors:
                        st.error(e)
                else:
                    register_user(s_user, s_email, s_pass)
                    st.success(f"✅ Account created for '{s_user.strip().lower()}'. Please log in.")

    # Stop rendering the rest of the app until logged in
    st.stop()


# ════════════════════════════════════════════════════════════════════════════
# LOGGED-IN APP
# ════════════════════════════════════════════════════════════════════════════

# ── Sidebar Navigation ──────────────────────────────────────────────────────
st.sidebar.title("🏗️ Sawastik Emirates")
st.sidebar.caption("Asset & Finance Manager")
st.sidebar.divider()

page = st.sidebar.radio(
    "Navigation",
    [
        "📊 Dashboard",
        "🏢 Asset Portfolio",
        "➕ Add Asset",
        "✏️ Edit Asset",
        "📅 Valuation History",
        "👥 Partner View",
        "📈 Analytics",
    ],
    label_visibility="collapsed",
)

# ── Cached data loaders ──────────────────────────────────────────────────────
@st.cache_data(show_spinner="Loading assets…")
def get_assets():
    return load_assets()

@st.cache_data(show_spinner="Loading valuations…")
def get_valuations():
    return load_all_valuations()

assets = get_assets()
valuations = get_valuations()

# ── Helper: build flat asset DataFrame ──────────────────────────────────────
def build_df(assets):
    rows = []
    for a in assets:
        rows.append({
            "ID": a["id"],
            "Asset Name": a["name"],
            "Category": a["category"],
            "Location": a["location"],
            "Total Value (AED)": a["total_value"],
            "Sawastik Share (%)": get_sawastik_share(a),
            "Sawastik Value (AED)": get_sawastik_value(a),
            "Purchase Date": a["purchase_date"],
            "Status": a["status"],
        })
    return pd.DataFrame(rows)

# ── Helper: build valuation DataFrame ───────────────────────────────────────
def build_val_df(valuations):
    if not valuations:
        return pd.DataFrame(columns=["asset_id", "asset_name", "category", "valuation_date", "value", "notes"])
    vdf = pd.DataFrame(valuations)
    vdf["valuation_date"] = pd.to_datetime(vdf["valuation_date"])
    vdf = vdf.rename(columns={
        "asset_name": "Asset",
        "value": "Value (AED)",
        "valuation_date": "Date",
        "category": "Category",
    })
    return vdf

df = build_df(assets)
vdf = build_val_df(valuations)

# ════════════════════════════════════════════════════════════════════════════
# PAGE: DASHBOARD
# ════════════════════════════════════════════════════════════════════════════
if page == "📊 Dashboard":
    st.title("📊 Dashboard Overview")
    st.caption("Sawastik Emirates – Real-time asset & finance summary")
    st.divider()

    # ── Compute investment baseline from earliest valuation per asset ────────
    total_portfolio = df["Total Value (AED)"].sum()
    sawastik_total = df["Sawastik Value (AED)"].sum()
    active_assets = len(df[df["Status"] == "Active"])
    avg_share = df["Sawastik Share (%)"].mean()

    if not vdf.empty:
        first_vals = (
            vdf.sort_values("Date")
            .groupby("asset_id")["Value (AED)"]
            .first()
        )
        total_investment = int(first_vals.sum())
    else:
        total_investment = int(total_portfolio)

    net_gain = int(total_portfolio) - total_investment
    net_gain_pct = (net_gain / total_investment * 100) if total_investment else 0
    gain_delta = f"{'+' if net_gain >= 0 else ''}{net_gain_pct:.1f}% vs initial investment"

    # ── KPI Cards ────────────────────────────────────────────────────────────
    st.markdown("### 📌 Key Performance Indicators")
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric(
        "🏦 Total Portfolio Value",
        f"AED {total_portfolio:,.0f}",
        help="Sum of current values across all assets",
    )
    k2.metric(
        "💰 Total Investment",
        f"AED {total_investment:,.0f}",
        help="Sum of each asset's earliest recorded valuation",
    )
    k3.metric(
        "📈 Net Gain",
        f"AED {net_gain:,.0f}",
        delta=gain_delta,
        delta_color="normal",
        help="Current portfolio value minus total investment",
    )
    k4.metric(
        "🏢 Active Assets",
        f"{active_assets} / {len(assets)}",
        help="Assets with status = Active",
    )
    k5.metric(
        "🤝 Avg Sawastik Share",
        f"{avg_share:.1f}%",
        help="Average Sawastik ownership percentage across all assets",
    )

    st.divider()

    # ── Charts Row ───────────────────────────────────────────────────────────
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Portfolio by Category")
        cat_df = df.groupby("Category")["Total Value (AED)"].sum().reset_index()
        fig_pie = px.pie(
            cat_df,
            names="Category",
            values="Total Value (AED)",
            hole=0.4,
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig_pie.update_layout(margin=dict(t=10, b=10, l=10, r=10), height=320)
        st.plotly_chart(fig_pie, use_container_width=True)

    with col2:
        st.subheader("Sawastik Share per Asset")
        fig_bar = px.bar(
            df.sort_values("Sawastik Value (AED)", ascending=False),
            x="Asset Name",
            y="Sawastik Value (AED)",
            color="Category",
            color_discrete_sequence=px.colors.qualitative.Set2,
            text_auto=".2s",
        )
        fig_bar.update_layout(
            margin=dict(t=10, b=10, l=10, r=10),
            height=320,
            xaxis_tickangle=-30,
            showlegend=False,
        )
        st.plotly_chart(fig_bar, use_container_width=True)

    # ── Portfolio Value Trend with Date Range Filter ─────────────────────────
    st.divider()
    st.subheader("📅 Portfolio Value Trend")

    if not vdf.empty:
        portfolio_trend_full = vdf.groupby("Date")["Value (AED)"].sum().reset_index()
        today = pd.Timestamp(datetime.date.today())
        if portfolio_trend_full["Date"].max() < today:
            portfolio_trend_full = pd.concat([
                portfolio_trend_full,
                pd.DataFrame([{"Date": today, "Value (AED)": int(total_portfolio)}])
            ], ignore_index=True)
        portfolio_trend_full = portfolio_trend_full.sort_values("Date")

        min_date = portfolio_trend_full["Date"].min().date()
        max_date = portfolio_trend_full["Date"].max().date()

        dr_col1, dr_col2, dr_col3 = st.columns([2, 2, 1])
        with dr_col1:
            range_start = st.date_input("From", value=min_date, min_value=min_date, max_value=max_date, key="dr_start")
        with dr_col2:
            range_end = st.date_input("To", value=max_date, min_value=min_date, max_value=max_date, key="dr_end")
        with dr_col3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Reset", use_container_width=True):
                range_start = min_date
                range_end = max_date

        if range_start > range_end:
            st.warning("'From' date must be before 'To' date.")
            portfolio_trend = portfolio_trend_full
        else:
            mask = (portfolio_trend_full["Date"].dt.date >= range_start) & \
                   (portfolio_trend_full["Date"].dt.date <= range_end)
            portfolio_trend = portfolio_trend_full[mask]

        if portfolio_trend.empty:
            st.info("No valuation data in the selected date range.")
        else:
            fig_trend = px.line(
                portfolio_trend,
                x="Date",
                y="Value (AED)",
                markers=True,
                labels={"Value (AED)": "Total Portfolio Value (AED)"},
                color_discrete_sequence=["#4C78A8"],
            )
            fig_trend.update_traces(line_width=2.5, marker_size=7)
            fig_trend.update_layout(
                height=320,
                margin=dict(t=10, b=10, l=10, r=10),
                yaxis_tickformat=",.0f",
            )
            st.plotly_chart(fig_trend, use_container_width=True)

            period_start_val = portfolio_trend["Value (AED)"].iloc[0]
            period_end_val = portfolio_trend["Value (AED)"].iloc[-1]
            period_gain = period_end_val - period_start_val
            period_gain_pct = (period_gain / period_start_val * 100) if period_start_val else 0
            g1, g2, g3 = st.columns(3)
            g1.metric(
                "Period Start Value",
                f"AED {period_start_val:,.0f}",
                help=f"Portfolio value on {portfolio_trend['Date'].iloc[0].date()}",
            )
            g2.metric(
                "Period End Value",
                f"AED {period_end_val:,.0f}",
                help=f"Portfolio value on {portfolio_trend['Date'].iloc[-1].date()}",
            )
            g3.metric(
                "Period Gain",
                f"AED {period_gain:,.0f}",
                delta=f"{'+' if period_gain >= 0 else ''}{period_gain_pct:.1f}%",
                delta_color="normal",
            )
    else:
        st.info("No valuation history yet. Add entries from the 📅 Valuation History page.")

    # ── Asset Growth Table (negative growth highlighted in red) ──────────────
    st.divider()
    st.subheader("📊 Asset Growth Overview")
    st.caption("Assets with negative growth are highlighted in red.")

    if not vdf.empty:
        growth_rows = []
        for a in assets:
            a_vdf = vdf[vdf["asset_id"] == a["id"]].sort_values("Date")
            if len(a_vdf) >= 2:
                first_v = int(a_vdf["Value (AED)"].iloc[0])
                last_v = int(a_vdf["Value (AED)"].iloc[-1])
                first_d = a_vdf["Date"].iloc[0].date()
                last_d = a_vdf["Date"].iloc[-1].date()
                chg = last_v - first_v
                chg_pct = (chg / first_v * 100) if first_v else 0
            elif len(a_vdf) == 1:
                first_v = last_v = int(a_vdf["Value (AED)"].iloc[0])
                first_d = last_d = a_vdf["Date"].iloc[0].date()
                chg = 0
                chg_pct = 0.0
            else:
                first_v = last_v = a["total_value"]
                first_d = last_d = a["purchase_date"]
                chg = 0
                chg_pct = 0.0
            growth_rows.append({
                "Asset": a["name"],
                "Category": a["category"],
                "Status": a["status"],
                "Initial Value (AED)": first_v,
                "Current Value (AED)": last_v,
                "Gain (AED)": chg,
                "Growth (%)": round(chg_pct, 2),
                "From": str(first_d),
                "To": str(last_d),
            })

        growth_df = pd.DataFrame(growth_rows).sort_values("Growth (%)", ascending=True)

        def _style_growth(row):
            if row["Growth (%)"] < 0:
                return ["color: #d62728; font-weight: bold"] * len(row)
            elif row["Growth (%)"] > 0:
                return ["color: #2ca02c; font-weight: bold"] * len(row)
            return [""] * len(row)

        styled_growth = (
            growth_df.style
            .apply(_style_growth, axis=1)
            .format({
                "Initial Value (AED)": "AED {:,.0f}",
                "Current Value (AED)": "AED {:,.0f}",
                "Gain (AED)": "AED {:,.0f}",
                "Growth (%)": "{:+.2f}%",
            })
        )
        st.dataframe(styled_growth, use_container_width=True, hide_index=True)

        neg_assets = [r["Asset"] for r in growth_rows if r["Growth (%)"] < 0]
        if neg_assets:
            st.warning(
                f"⚠️ **{len(neg_assets)} asset(s) showing negative growth:** {', '.join(neg_assets)}"
            )
        else:
            st.success("✅ All assets are showing positive or neutral growth.")
    else:
        st.dataframe(
            df[["Asset Name", "Category", "Status", "Total Value (AED)", "Sawastik Share (%)"]].style.format({
                "Total Value (AED)": "AED {:,.0f}", "Sawastik Share (%)": "{:.0f}%"
            }),
            use_container_width=True, hide_index=True,
        )
        st.info("Log valuations on the 📅 Valuation History page to track growth over time.")

    # ── Download Report ──────────────────────────────────────────────────────
    st.divider()
    st.subheader("📄 Download Portfolio Report")
    st.caption(
        "Generates a branded PDF containing the KPI summary, asset portfolio, "
        "growth analysis, partner breakdown, and full valuation history."
    )

    if st.button("⬇️ Generate PDF Report", type="primary", use_container_width=False):
        with st.spinner("Building your report…"):
            try:
                pdf_bytes = generate_report(
                    assets=assets,
                    valuations=valuations,
                    total_portfolio=int(total_portfolio),
                    total_investment=total_investment,
                    net_gain=net_gain,
                    net_gain_pct=net_gain_pct,
                    active_assets=active_assets,
                    avg_share=avg_share,
                    generated_by=st.session_state.get("username", "Sawastik Emirates"),
                )
                today_label = datetime.date.today().strftime("%Y-%m-%d")
                st.download_button(
                    label="📥 Click here to download the PDF",
                    data=pdf_bytes,
                    file_name=f"sawastik_portfolio_report_{today_label}.pdf",
                    mime="application/pdf",
                    type="primary",
                    use_container_width=False,
                )
                st.success("✅ Report ready — click the button above to save it.")
            except Exception as e:
                st.error(f"Failed to generate report: {e}")


# ════════════════════════════════════════════════════════════════════════════
# PAGE: ASSET PORTFOLIO
# ════════════════════════════════════════════════════════════════════════════
elif page == "🏢 Asset Portfolio":
    st.title("🏢 Asset Portfolio")
    st.divider()

    col1, col2, col3 = st.columns(3)
    with col1:
        cats = ["All"] + sorted(df["Category"].unique().tolist())
        cat_filter = st.selectbox("Filter by Category", cats)
    with col2:
        statuses = ["All"] + sorted(df["Status"].unique().tolist())
        status_filter = st.selectbox("Filter by Status", statuses)
    with col3:
        search = st.text_input("Search by Name / Location")

    filtered = df.copy()
    if cat_filter != "All":
        filtered = filtered[filtered["Category"] == cat_filter]
    if status_filter != "All":
        filtered = filtered[filtered["Status"] == status_filter]
    if search:
        mask = (
            filtered["Asset Name"].str.contains(search, case=False)
            | filtered["Location"].str.contains(search, case=False)
        )
        filtered = filtered[mask]

    st.caption(f"Showing {len(filtered)} of {len(df)} assets")
    st.dataframe(
        filtered[
            ["Asset Name", "Category", "Location", "Total Value (AED)",
             "Sawastik Share (%)", "Sawastik Value (AED)", "Status", "Purchase Date"]
        ].style.format({
            "Total Value (AED)": "AED {:,.0f}",
            "Sawastik Value (AED)": "AED {:,.0f}",
            "Sawastik Share (%)": "{:.0f}%",
        }),
        use_container_width=True,
        hide_index=True,
    )

    st.divider()
    st.subheader("Asset Details")
    asset_names = df["Asset Name"].tolist()
    selected_name = st.selectbox("Select an asset to view partners", asset_names)
    selected_asset = next(a for a in assets if a["name"] == selected_name)

    col1, col2 = st.columns([1, 2])
    with col1:
        st.markdown(f"**Category:** {selected_asset['category']}")
        st.markdown(f"**Location:** {selected_asset['location']}")
        st.markdown(f"**Total Value:** AED {selected_asset['total_value']:,}")
        st.markdown(f"**Status:** {selected_asset['status']}")
        st.markdown(f"**Purchase Date:** {selected_asset['purchase_date']}")

    with col2:
        partners_df = pd.DataFrame(selected_asset["partners"])
        partners_df["Value (AED)"] = partners_df["share_pct"] / 100 * selected_asset["total_value"]
        fig = px.pie(
            partners_df,
            names="name",
            values="share_pct",
            title="Partner Share Distribution",
            hole=0.35,
            color_discrete_sequence=px.colors.qualitative.Pastel,
        )
        fig.update_layout(margin=dict(t=40, b=10, l=10, r=10), height=260)
        st.plotly_chart(fig, use_container_width=True)

    st.dataframe(
        partners_df.rename(columns={"name": "Partner", "share_pct": "Share (%)"})
        .style.format({"Share (%)": "{:.0f}%", "Value (AED)": "AED {:,.0f}"}),
        use_container_width=True,
        hide_index=True,
    )

    st.divider()
    with st.expander("⚠️ Delete this asset"):
        if st.button(f"Delete '{selected_name}'", type="primary"):
            delete_asset(selected_asset["id"])
            get_assets.clear()
            get_valuations.clear()
            st.success(f"'{selected_name}' deleted from database.")
            st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PAGE: ADD ASSET
# ════════════════════════════════════════════════════════════════════════════
elif page == "➕ Add Asset":
    st.title("➕ Add New Asset")
    st.divider()

    with st.form("add_asset_form"):
        c1, c2 = st.columns(2)
        with c1:
            name = st.text_input("Asset Name *")
            category = st.selectbox(
                "Category *", ["Commercial", "Residential", "Retail", "Industrial", "Mixed-Use", "Other"]
            )
            location = st.text_input("Location *")
        with c2:
            total_value = st.number_input("Total Value (AED) *", min_value=0, step=100000)
            purchase_date = st.date_input("Purchase Date *")
            status = st.selectbox("Status *", ["Active", "Under Review", "Sold", "On Hold"])

        st.subheader("Partner Shareholding")
        st.caption("Add at least one partner. Shares must sum to 100%.")
        num_partners = st.number_input("Number of Partners", min_value=1, max_value=6, value=2, step=1)
        partners = []
        cols = st.columns(2)
        for i in range(int(num_partners)):
            col = cols[i % 2]
            with col:
                p_name = st.text_input(f"Partner {i+1} Name", key=f"pname_{i}")
                p_share = st.number_input(
                    f"Partner {i+1} Share (%)", min_value=0.0, max_value=100.0, step=0.5, key=f"pshare_{i}"
                )
                if p_name:
                    partners.append({"name": p_name, "share_pct": p_share})
        submitted = st.form_submit_button("💾 Save Asset", type="primary", use_container_width=True)

    if submitted:
        errors = []
        if not name:
            errors.append("Asset name is required.")
        if not location:
            errors.append("Location is required.")
        if total_value <= 0:
            errors.append("Total value must be greater than 0.")
        if not partners:
            errors.append("Add at least one partner.")
        else:
            total_pct = sum(p["share_pct"] for p in partners)
            if abs(total_pct - 100) > 0.5:
                errors.append(f"Partner shares must sum to 100% (currently {total_pct:.1f}%).")
        if errors:
            for e in errors:
                st.error(e)
        else:
            new_id = add_asset(
                name=name, category=category, location=location,
                total_value=int(total_value), purchase_date=str(purchase_date),
                status=status, partners=partners,
            )
            add_valuation(new_id, str(purchase_date), int(total_value), "Initial valuation on asset creation")
            get_assets.clear()
            get_valuations.clear()
            st.success(f"✅ Asset '{name}' saved to database!")
            st.balloons()


# ════════════════════════════════════════════════════════════════════════════
# PAGE: EDIT ASSET
# ════════════════════════════════════════════════════════════════════════════
elif page == "✏️ Edit Asset":
    st.title("✏️ Edit Asset")
    st.divider()

    asset_options = {a["name"]: a for a in assets}
    selected_name = st.selectbox("Select asset to edit", list(asset_options.keys()))
    sel = asset_options[selected_name]
    st.caption(f"Editing asset ID {sel['id']} — changes are saved directly to the database.")
    st.divider()

    CATEGORIES = ["Commercial", "Residential", "Retail", "Industrial", "Mixed-Use", "Other"]
    STATUSES = ["Active", "Under Review", "Sold", "On Hold"]
    cat_index = CATEGORIES.index(sel["category"]) if sel["category"] in CATEGORIES else 0
    status_index = STATUSES.index(sel["status"]) if sel["status"] in STATUSES else 0

    try:
        existing_date = datetime.date.fromisoformat(str(sel["purchase_date"])[:10])
    except ValueError:
        existing_date = datetime.date.today()

    with st.form("edit_asset_form"):
        c1, c2 = st.columns(2)
        with c1:
            e_name = st.text_input("Asset Name *", value=sel["name"])
            e_category = st.selectbox("Category *", CATEGORIES, index=cat_index)
            e_location = st.text_input("Location *", value=sel["location"])
        with c2:
            e_value = st.number_input("Total Value (AED) *", min_value=0, step=100000, value=int(sel["total_value"]))
            e_date = st.date_input("Purchase Date *", value=existing_date)
            e_status = st.selectbox("Status *", STATUSES, index=status_index)

        st.subheader("Partner Shareholding")
        st.caption("Shares must sum to 100%. Existing partners are pre-filled.")
        existing_partners = sel["partners"]
        num_partners = st.number_input(
            "Number of Partners", min_value=1, max_value=6,
            value=max(len(existing_partners), 1), step=1
        )
        partners = []
        cols = st.columns(2)
        for i in range(int(num_partners)):
            col = cols[i % 2]
            existing = existing_partners[i] if i < len(existing_partners) else {}
            with col:
                p_name = st.text_input(f"Partner {i+1} Name", value=existing.get("name", ""), key=f"ep_name_{i}")
                p_share = st.number_input(
                    f"Partner {i+1} Share (%)", min_value=0.0, max_value=100.0, step=0.5,
                    value=float(existing.get("share_pct", 0.0)), key=f"ep_share_{i}"
                )
                if p_name:
                    partners.append({"name": p_name, "share_pct": p_share})
        total_pct_preview = sum(p["share_pct"] for p in partners)
        if partners:
            color = "green" if abs(total_pct_preview - 100) <= 0.5 else "red"
            st.markdown(f"**Share total:** :{color}[{total_pct_preview:.1f}%]")
        save_btn = st.form_submit_button("💾 Save Changes", type="primary", use_container_width=True)

    if save_btn:
        errors = []
        if not e_name:
            errors.append("Asset name is required.")
        if not e_location:
            errors.append("Location is required.")
        if e_value <= 0:
            errors.append("Total value must be greater than 0.")
        if not partners:
            errors.append("Add at least one partner.")
        else:
            total_pct = sum(p["share_pct"] for p in partners)
            if abs(total_pct - 100) > 0.5:
                errors.append(f"Partner shares must sum to 100% (currently {total_pct:.1f}%).")
        if errors:
            for e in errors:
                st.error(e)
        else:
            update_asset(
                asset_id=sel["id"], name=e_name, category=e_category, location=e_location,
                total_value=int(e_value), purchase_date=str(e_date), status=e_status, partners=partners,
            )
            get_assets.clear()
            st.success(f"✅ '{e_name}' updated successfully in the database.")
            st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PAGE: VALUATION HISTORY
# ════════════════════════════════════════════════════════════════════════════
elif page == "📅 Valuation History":
    st.title("📅 Valuation History")
    st.caption("Track how each asset's value has changed over time.")
    st.divider()

    if vdf.empty:
        st.info("No valuation records found. Log your first entry below.")
    else:
        all_asset_names = sorted(vdf["Asset"].unique().tolist())
        selected_assets = st.multiselect(
            "Select assets to compare (leave empty = show all)",
            all_asset_names, default=[],
        )
        chart_df = vdf if not selected_assets else vdf[vdf["Asset"].isin(selected_assets)]

        st.subheader("Asset Value Trend Lines")
        fig_lines = px.line(
            chart_df.sort_values("Date"),
            x="Date", y="Value (AED)", color="Asset", markers=True,
            labels={"Value (AED)": "Value (AED)", "Date": "Valuation Date"},
            color_discrete_sequence=px.colors.qualitative.Set1,
        )
        fig_lines.update_traces(line_width=2, marker_size=7)
        fig_lines.update_layout(
            height=400, margin=dict(t=10, b=10, l=10, r=10), yaxis_tickformat=",.0f",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        )
        st.plotly_chart(fig_lines, use_container_width=True)

        st.subheader("Appreciation Since First Record")
        gain_rows = []
        for asset_name, grp in vdf.groupby("Asset"):
            grp_sorted = grp.sort_values("Date")
            first_val = grp_sorted["Value (AED)"].iloc[0]
            last_val = grp_sorted["Value (AED)"].iloc[-1]
            change_pct = ((last_val - first_val) / first_val * 100) if first_val else 0
            gain_rows.append({
                "Asset": asset_name,
                "First Value (AED)": first_val,
                "Latest Value (AED)": last_val,
                "Gain (AED)": last_val - first_val,
                "Gain (%)": change_pct,
                "From": str(grp_sorted["Date"].iloc[0].date()),
                "To": str(grp_sorted["Date"].iloc[-1].date()),
            })
        gain_df = pd.DataFrame(gain_rows).sort_values("Gain (%)", ascending=False)
        fig_gain = px.bar(
            gain_df, x="Asset", y="Gain (%)",
            color="Gain (%)", color_continuous_scale=["#d73027", "#fee090", "#4dac26"],
            text_auto=".1f",
        )
        fig_gain.update_traces(texttemplate="%{text}%")
        fig_gain.update_layout(
            height=320, margin=dict(t=10, b=10, l=10, r=10),
            coloraxis_showscale=False, xaxis_tickangle=-20,
        )
        st.plotly_chart(fig_gain, use_container_width=True)
        st.dataframe(
            gain_df.style.format({
                "First Value (AED)": "AED {:,.0f}", "Latest Value (AED)": "AED {:,.0f}",
                "Gain (AED)": "AED {:,.0f}", "Gain (%)": "{:.1f}%",
            }),
            use_container_width=True, hide_index=True,
        )

    st.divider()
    st.subheader("Log a New Valuation")
    asset_name_map = {a["name"]: a["id"] for a in assets}
    with st.form("log_valuation_form"):
        lc1, lc2 = st.columns(2)
        with lc1:
            lv_asset = st.selectbox("Asset *", list(asset_name_map.keys()))
            lv_date = st.date_input("Valuation Date *", value=datetime.date.today())
        with lc2:
            lv_value = st.number_input("Value (AED) *", min_value=0, step=100000)
            lv_notes = st.text_input("Notes (optional)", placeholder="e.g. Q2 2025 appraisal")
        log_btn = st.form_submit_button("📌 Log Valuation", type="primary", use_container_width=True)

    if log_btn:
        if lv_value <= 0:
            st.error("Value must be greater than 0.")
        else:
            add_valuation(
                asset_id=asset_name_map[lv_asset],
                valuation_date=str(lv_date), value=int(lv_value), notes=lv_notes,
            )
            get_valuations.clear()
            st.success(f"✅ Valuation logged for '{lv_asset}' on {lv_date}.")
            st.rerun()

    if not vdf.empty:
        st.divider()
        st.subheader("Full Valuation History")
        filter_asset = st.selectbox(
            "Filter by asset", ["All"] + sorted(vdf["Asset"].unique().tolist()), key="hist_filter"
        )
        history_df = vdf if filter_asset == "All" else vdf[vdf["Asset"] == filter_asset]
        history_df = history_df.sort_values(["Asset", "Date"], ascending=[True, False])
        display_cols = [c for c in ["id", "Asset", "Category", "Date", "Value (AED)", "notes"] if c in history_df.columns]
        show_df = history_df[display_cols].copy()
        show_df["Date"] = show_df["Date"].dt.date
        st.dataframe(
            show_df.rename(columns={"id": "ID", "notes": "Notes"})
            .style.format({"Value (AED)": "AED {:,.0f}"}),
            use_container_width=True, hide_index=True,
        )
        with st.expander("🗑️ Delete a valuation entry"):
            del_id = st.number_input("Enter Valuation ID to delete", min_value=1, step=1)
            if st.button("Delete Entry", type="primary"):
                delete_valuation(int(del_id))
                get_valuations.clear()
                st.success(f"Valuation ID {del_id} deleted.")
                st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PAGE: PARTNER VIEW
# ════════════════════════════════════════════════════════════════════════════
elif page == "👥 Partner View":
    st.title("👥 Partner View")
    st.divider()

    partner_rows = []
    for a in assets:
        for p in a["partners"]:
            partner_rows.append({
                "Partner": p["name"],
                "Asset": a["name"],
                "Category": a["category"],
                "Asset Total (AED)": a["total_value"],
                "Share (%)": p["share_pct"],
                "Value (AED)": a["total_value"] * p["share_pct"] / 100,
            })
    partner_df = pd.DataFrame(partner_rows)
    all_partners = sorted(partner_df["Partner"].unique().tolist())
    selected_partner = st.selectbox("Select Partner", all_partners)
    p_df = partner_df[partner_df["Partner"] == selected_partner]

    c1, c2, c3 = st.columns(3)
    c1.metric("Total Assets", len(p_df))
    c2.metric("Total Invested (AED)", f"AED {p_df['Value (AED)'].sum():,.0f}")
    c3.metric("Avg Share", f"{p_df['Share (%)'].mean():.1f}%")

    st.divider()
    col1, col2 = st.columns(2)
    with col1:
        fig = px.bar(
            p_df.sort_values("Value (AED)", ascending=True),
            x="Value (AED)", y="Asset", orientation="h", color="Category",
            color_discrete_sequence=px.colors.qualitative.Set2,
            title=f"{selected_partner}'s Investments by Asset",
        )
        fig.update_layout(height=300, margin=dict(t=40, b=10, l=10, r=10), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        cat_sum = p_df.groupby("Category")["Value (AED)"].sum().reset_index()
        fig2 = px.pie(
            cat_sum, names="Category", values="Value (AED)", hole=0.4,
            title=f"{selected_partner}'s Portfolio by Category",
            color_discrete_sequence=px.colors.qualitative.Pastel,
        )
        fig2.update_layout(height=300, margin=dict(t=40, b=10, l=10, r=10))
        st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Asset Breakdown")
    st.dataframe(
        p_df[["Asset", "Category", "Asset Total (AED)", "Share (%)", "Value (AED)"]].style.format({
            "Asset Total (AED)": "AED {:,.0f}", "Value (AED)": "AED {:,.0f}", "Share (%)": "{:.0f}%",
        }),
        use_container_width=True, hide_index=True,
    )

    st.divider()
    st.subheader("All Partners Summary")
    summary = (
        partner_df.groupby("Partner")
        .agg(Assets=("Asset", "count"), Total_Value=("Value (AED)", "sum"), Avg_Share=("Share (%)", "mean"))
        .reset_index()
        .rename(columns={"Total_Value": "Total Value (AED)", "Avg_Share": "Avg Share (%)"})
        .sort_values("Total Value (AED)", ascending=False)
    )
    st.dataframe(
        summary.style.format({"Total Value (AED)": "AED {:,.0f}", "Avg Share (%)": "{:.1f}%"}),
        use_container_width=True, hide_index=True,
    )


# ════════════════════════════════════════════════════════════════════════════
# PAGE: ANALYTICS
# ════════════════════════════════════════════════════════════════════════════
elif page == "📈 Analytics":
    st.title("📈 Analytics")
    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Asset Value by Category")
        cat_df = df.groupby("Category").agg(
            Assets=("Asset Name", "count"),
            Total_Value=("Total Value (AED)", "sum"),
            Sawastik_Value=("Sawastik Value (AED)", "sum"),
        ).reset_index()
        fig = px.bar(
            cat_df, x="Category", y=["Total_Value", "Sawastik_Value"], barmode="group",
            labels={"value": "Value (AED)", "variable": ""},
            color_discrete_map={"Total_Value": "#4C78A8", "Sawastik_Value": "#F58518"},
        )
        fig.update_layout(height=320, margin=dict(t=10, b=10, l=10, r=10))
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Sawastik Share % per Asset")
        fig2 = px.bar(
            df.sort_values("Sawastik Share (%)", ascending=False),
            x="Asset Name", y="Sawastik Share (%)", color="Category",
            color_discrete_sequence=px.colors.qualitative.Set2, text_auto=".0f",
        )
        fig2.update_traces(texttemplate="%{text}%")
        fig2.update_layout(
            height=320, margin=dict(t=10, b=10, l=10, r=10),
            xaxis_tickangle=-30, showlegend=False,
        )
        st.plotly_chart(fig2, use_container_width=True)

    st.divider()
    st.subheader("Portfolio Value Waterfall")
    fig3 = go.Figure(go.Waterfall(
        name="Portfolio", orientation="v",
        measure=["relative"] * len(df) + ["total"],
        x=df["Asset Name"].tolist() + ["Total"],
        y=df["Total Value (AED)"].tolist() + [0],
        connector={"line": {"color": "rgb(63, 63, 63)"}},
        increasing={"marker": {"color": "#4C78A8"}},
        totals={"marker": {"color": "#F58518"}},
    ))
    fig3.update_layout(height=360, margin=dict(t=10, b=10, l=10, r=10), showlegend=False)
    st.plotly_chart(fig3, use_container_width=True)

    if not vdf.empty:
        st.divider()
        st.subheader("Per-Asset Value History")
        st.caption("Line chart showing each asset's appraised value across all recorded dates.")
        fig_hist = px.line(
            vdf.sort_values("Date"), x="Date", y="Value (AED)", color="Asset",
            facet_col="Asset", facet_col_wrap=3, markers=True,
            color_discrete_sequence=px.colors.qualitative.Set1,
        )
        fig_hist.update_traces(line_width=2, marker_size=5)
        fig_hist.update_layout(height=500, margin=dict(t=40, b=10, l=10, r=10), showlegend=False)
        fig_hist.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1]))
        fig_hist.update_yaxes(tickformat=",.0f", matches=None)
        st.plotly_chart(fig_hist, use_container_width=True)

    st.divider()
    st.subheader("Status Distribution")
    status_df = df["Status"].value_counts().reset_index()
    status_df.columns = ["Status", "Count"]
    fig4 = px.pie(
        status_df, names="Status", values="Count", hole=0.4,
        color_discrete_sequence=px.colors.qualitative.Safe,
    )
    fig4.update_layout(height=280, margin=dict(t=10, b=10, l=10, r=10))
    st.plotly_chart(fig4, use_container_width=True)


# ── Sidebar footer ───────────────────────────────────────────────────────────
st.sidebar.divider()
st.sidebar.caption(f"Logged in as  **{st.session_state.username}**")
total_val = df["Total Value (AED)"].sum()
sawastik_val = df["Sawastik Value (AED)"].sum()
st.sidebar.metric("Portfolio", f"AED {total_val:,.0f}")
st.sidebar.metric("Your Share", f"AED {sawastik_val:,.0f}")
st.sidebar.divider()
if st.sidebar.button("🚪 Logout", use_container_width=True):
    st.session_state.logged_in = False
    st.session_state.username = ""
    st.rerun()
