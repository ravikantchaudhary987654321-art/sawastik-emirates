"""
main.py — Central hub for Sawastik Emirates Asset & Finance Manager.

Architecture:
  - Reads BUSINESS_UNITS from config.py
  - Dynamically imports page modules from modules/<unit_id>/<page_id>.py
  - Each module exposes render(ctx) and is completely self-contained
  - Adding a new business unit = add a folder in /modules + one line in config.py
"""

import importlib
import os

import pandas as pd
import streamlit as st
from PIL import Image

from config import BUSINESS_UNITS
import streamlit.components.v1 as components

from data import (
    authenticate_user,
    email_exists,
    load_all_valuations,
    load_assets,
    register_user,
    username_exists,
    get_sawastik_share,
    get_sawastik_value,
    get_user_by_username,
    create_reset_token,
    verify_reset_token,
    consume_reset_token,
    create_session_token,
    validate_session_token,
    revoke_session_token,
)

# ── Logo & favicon ────────────────────────────────────────────────────────────
_LOGO_PATH = os.path.join(os.path.dirname(__file__), "logo.png")
_logo_img  = Image.open(_LOGO_PATH) if os.path.exists(_LOGO_PATH) else None

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Sawastik Emirates - Asset & Finance Manager",
    page_icon=_logo_img if _logo_img else "🏗️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Brand CSS — deep navy + gold ──────────────────────────────────────────────
st.markdown("""
<style>
/* ── Metric cards ─────────────────────────────────────────────────── */
[data-testid="stMetric"] {
    background: linear-gradient(135deg, #162A4A 0%, #1a3055 100%);
    border: 1px solid rgba(201,168,76,0.35);
    border-radius: 10px;
    padding: 14px 18px !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.4);
}
[data-testid="stMetricLabel"] > div {
    color: #C9A84C !important;
    font-size: 0.72rem !important;
    font-weight: 700 !important;
    text-transform: uppercase;
    letter-spacing: 0.07em;
}
[data-testid="stMetricValue"] > div {
    color: #F5F0E8 !important;
    font-size: 1.35rem !important;
    font-weight: 800 !important;
}
[data-testid="stMetricDelta"] svg { display: none; }
[data-testid="stMetricDelta"] > div {
    color: #C9A84C !important;
    font-size: 0.8rem !important;
    font-weight: 600 !important;
}

/* ── Page title h1 ────────────────────────────────────────────────── */
h1 {
    color: #F5F0E8 !important;
    border-bottom: 2px solid #C9A84C;
    padding-bottom: 0.4rem;
    margin-bottom: 0.2rem;
}
h2, h3 { color: #C9A84C !important; }

/* ── Dividers ─────────────────────────────────────────────────────── */
hr { border-color: rgba(201,168,76,0.25) !important; }

/* ── Sidebar brand strip ──────────────────────────────────────────── */
[data-testid="stSidebar"] [data-testid="stVerticalBlock"]:first-child {
    padding-top: 0.5rem;
}
[data-testid="stSidebar"] .stMarkdown p {
    color: #C9A84C !important;
    font-weight: 600;
}

/* ── Primary buttons → gold ───────────────────────────────────────── */
button[kind="primary"] {
    background: linear-gradient(135deg, #C9A84C, #D4AF37) !important;
    color: #0D1F3C !important;
    font-weight: 800 !important;
    border: none !important;
    border-radius: 7px !important;
    letter-spacing: 0.02em;
    box-shadow: 0 2px 8px rgba(201,168,76,0.35);
    transition: transform .15s, box-shadow .15s;
}
button[kind="primary"]:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 16px rgba(201,168,76,0.55) !important;
}

/* ── DataFrames ───────────────────────────────────────────────────── */
[data-testid="stDataFrame"] {
    border: 1px solid rgba(201,168,76,0.3) !important;
    border-radius: 8px;
    overflow: hidden;
}

/* ── Caption / muted text ─────────────────────────────────────────── */
[data-testid="stCaptionContainer"] p { color: rgba(201,168,76,0.7) !important; }

/* ── Info / success / warning banners ────────────────────────────── */
[data-testid="stAlert"] { border-radius: 8px; }

/* ── Sidebar nav radio items ──────────────────────────────────────── */
[data-testid="stSidebar"] label {
    font-size: 0.93rem;
    padding: 3px 0;
}

/* ── Logo glow in sidebar ─────────────────────────────────────────── */
[data-testid="stSidebar"] img {
    filter: drop-shadow(0 0 10px rgba(201,168,76,0.45));
    border-radius: 8px;
}

/* ── Section markdown h3 subheadings ──────────────────────────────── */
.stMarkdown h3 {
    border-left: 3px solid #C9A84C;
    padding-left: 8px;
}
</style>
""", unsafe_allow_html=True)

# ── Dev bypass + session config ───────────────────────────────────────────────
_DEV_TOKEN  = os.environ.get("ADMIN_DEV_TOKEN", "")    # set in Replit Secrets
_ADMIN_USER = os.environ.get("ADMIN_USERNAME",  "")    # username to auto-login as
_COOKIE_NAME = "swk_session"
_SESSION_DAYS = 30


def _set_session_cookie(token: str) -> None:
    """Inject JS into the parent frame to write a persistent session cookie."""
    components.html(
        f"<script>"
        f"window.parent.document.cookie = "
        f"'{_COOKIE_NAME}={token}; max-age={_SESSION_DAYS * 86400}; path=/; SameSite=Strict';"
        f"</script>",
        height=0,
    )


def _clear_session_cookie() -> None:
    """Inject JS to delete the session cookie immediately."""
    components.html(
        f"<script>"
        f"window.parent.document.cookie = "
        f"'{_COOKIE_NAME}=; max-age=0; path=/; SameSite=Strict';"
        f"</script>",
        height=0,
    )


# ════════════════════════════════════════════════════════════════════════════
# AUTH GATE
# ════════════════════════════════════════════════════════════════════════════

# ── Init session state ────────────────────────────────────────────────────────
if "logged_in" not in st.session_state:
    st.session_state.logged_in  = False
    st.session_state.username   = ""
    st.session_state.dev_bypass = False

# ── 1. Developer bypass via URL query param ──────────────────────────────────
#    Access: https://<your-app-url>/?dev=<ADMIN_DEV_TOKEN>
#    Only activates when ADMIN_DEV_TOKEN env var is set AND the URL param matches.
if (
    not st.session_state.logged_in
    and _DEV_TOKEN
    and _ADMIN_USER
    and st.query_params.get("dev", "") == _DEV_TOKEN
):
    _bypass_user = get_user_by_username(_ADMIN_USER)
    if _bypass_user:
        st.session_state.logged_in  = True
        st.session_state.username   = _bypass_user["username"]
        st.session_state.dev_bypass = True

# ── 2. Persistent session cookie (30-day remember-me) ────────────────────────
if not st.session_state.logged_in:
    _cookie_token = st.context.cookies.get(_COOKIE_NAME, "")
    if _cookie_token:
        _cookie_user = validate_session_token(_cookie_token)
        if _cookie_user:
            st.session_state.logged_in  = True
            st.session_state.username   = _cookie_user["username"]
            st.session_state.dev_bypass = False

if not st.session_state.logged_in:
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        st.markdown("## 🏗️ Sawastik Emirates")
        st.markdown("#### Asset & Finance Manager")
        st.divider()

        tab_login, tab_signup, tab_reset = st.tabs(
            ["🔑 Login", "📝 Sign Up", "🔓 Forgot Password"]
        )

        # ── Login ──────────────────────────────────────────────────────────────
        with tab_login:
            with st.form("login_form"):
                l_user     = st.text_input("Username")
                l_pass     = st.text_input("Password", type="password")
                l_remember = st.checkbox(
                    f"Remember me for {_SESSION_DAYS} days",
                    help="Keeps you logged in across browser sessions using a secure token.",
                )
                login_btn = st.form_submit_button("Login", type="primary",
                                                  use_container_width=True)
            if login_btn:
                if not l_user or not l_pass:
                    st.error("Please enter both username and password.")
                else:
                    user = authenticate_user(l_user, l_pass)
                    if user:
                        st.session_state.logged_in  = True
                        st.session_state.username   = user["username"]
                        st.session_state.dev_bypass = False
                        if l_remember:
                            _tok = create_session_token(user["id"], days=_SESSION_DAYS)
                            _set_session_cookie(_tok)
                        st.rerun()
                    else:
                        st.error("Invalid username or password.")

        # ── Sign Up ────────────────────────────────────────────────────────────
        with tab_signup:
            with st.form("signup_form"):
                s_user  = st.text_input("Username")
                s_email = st.text_input("Email")
                s_pass  = st.text_input("Password", type="password")
                s_pass2 = st.text_input("Confirm Password", type="password")
                signup_btn = st.form_submit_button("Create Account", type="primary",
                                                   use_container_width=True)
            if signup_btn:
                errors = []
                if not s_user or not s_email or not s_pass:
                    errors.append("All fields are required.")
                elif len(s_user.strip()) < 3:
                    errors.append("Username must be at least 3 characters.")
                elif len(s_pass) < 8:
                    errors.append("Password must be at least 8 characters.")
                elif s_pass != s_pass2:
                    errors.append("Passwords do not match.")
                elif "@" not in s_email or "." not in s_email:
                    errors.append("Please enter a valid email address.")
                elif username_exists(s_user):
                    errors.append("That username is already taken.")
                elif email_exists(s_email):
                    errors.append("An account with that email already exists.")
                for e in errors:
                    st.error(e)
                if not errors:
                    register_user(s_user, s_email, s_pass)
                    st.success(f"✅ Account created for '{s_user.strip().lower()}'. Please log in.")

        # ── Forgot Password ────────────────────────────────────────────────────
        with tab_reset:
            # Session state keys used only in this tab
            if "reset_token"    not in st.session_state:
                st.session_state.reset_token    = None
            if "reset_username" not in st.session_state:
                st.session_state.reset_username = None

            # ── Step 1: Request a reset code ───────────────────────────────────
            st.markdown("#### Step 1 — Request a reset code")
            st.caption(
                "Enter your username or email address. "
                "A one-time reset code will be generated and shown here — "
                "it expires in **1 hour** and can only be used once."
            )

            with st.form("request_reset_form"):
                r_identifier = st.text_input("Username or Email")
                request_btn  = st.form_submit_button(
                    "Generate Reset Code", type="primary", use_container_width=True
                )

            if request_btn:
                if not r_identifier.strip():
                    st.error("Please enter your username or email.")
                else:
                    result = create_reset_token(r_identifier)
                    if result is None:
                        # Deliberately vague — don't confirm whether the account exists
                        st.warning(
                            "If an account with that username or email exists, "
                            "a reset code has been generated below."
                        )
                    else:
                        token, uname = result
                        st.session_state.reset_token    = token
                        st.session_state.reset_username = uname

            if st.session_state.reset_token:
                st.markdown(
                    "<div style='background:#162A4A; border:1px solid #C9A84C; "
                    "border-radius:8px; padding:14px 18px; margin:12px 0;'>"
                    "<p style='color:#C9A84C; font-weight:700; margin:0 0 6px;'>"
                    "⚠️ Copy this code — it will not be shown again after you leave this page</p>"
                    f"<code style='font-size:1.05rem; letter-spacing:0.08em; "
                    f"color:#F5F0E8;'>{st.session_state.reset_token}</code><br/>"
                    f"<small style='color:rgba(245,240,232,0.55);'>"
                    f"Account: {st.session_state.reset_username}</small>"
                    "</div>",
                    unsafe_allow_html=True,
                )

            st.divider()

            # ── Step 2: Use the code to set a new password ─────────────────────
            st.markdown("#### Step 2 — Set a new password")
            st.caption("Paste the reset code from Step 1 and choose a new password.")

            with st.form("use_reset_form"):
                r_code  = st.text_input("Reset Code", placeholder="Paste your reset code here")
                r_pass1 = st.text_input("New Password",     type="password")
                r_pass2 = st.text_input("Confirm Password", type="password")
                reset_btn = st.form_submit_button(
                    "Reset Password", type="primary", use_container_width=True
                )

            if reset_btn:
                errors = []
                if not r_code.strip():
                    errors.append("Please enter the reset code.")
                if not r_pass1:
                    errors.append("Please enter a new password.")
                elif len(r_pass1) < 8:
                    errors.append("Password must be at least 8 characters.")
                elif r_pass1 != r_pass2:
                    errors.append("Passwords do not match.")
                for e in errors:
                    st.error(e)
                if not errors:
                    # Verify code is valid before committing
                    token_user = verify_reset_token(r_code.strip())
                    if token_user is None:
                        st.error(
                            "❌ That reset code is invalid, already used, or has expired. "
                            "Please generate a new one in Step 1."
                        )
                    else:
                        ok = consume_reset_token(r_code.strip(), r_pass1)
                        if ok:
                            st.session_state.reset_token    = None
                            st.session_state.reset_username = None
                            st.success(
                                f"✅ Password updated for **{token_user['username']}**. "
                                "You can now log in with your new password."
                            )
                        else:
                            st.error("Something went wrong — please try again.")

    st.stop()


# ════════════════════════════════════════════════════════════════════════════
# SHARED CACHED DATA LOADERS
# ════════════════════════════════════════════════════════════════════════════
@st.cache_data(show_spinner="Loading assets…")
def get_assets():
    return load_assets()


@st.cache_data(show_spinner="Loading valuations…")
def get_valuations():
    return load_all_valuations()


def build_df(assets: list) -> pd.DataFrame:
    rows = []
    for a in assets:
        rows.append({
            "ID":                   a["id"],
            "Asset Name":           a["name"],
            "Category":             a["category"],
            "Location":             a["location"],
            "Total Value (AED)":    a["total_value"],
            "Sawastik Share (%)":   get_sawastik_share(a),
            "Sawastik Value (AED)": get_sawastik_value(a),
            "Purchase Date":        a["purchase_date"],
            "Status":               a["status"],
        })
    return pd.DataFrame(rows)


def build_val_df(valuations: list) -> pd.DataFrame:
    if not valuations:
        return pd.DataFrame(
            columns=["asset_id", "asset_name", "category", "valuation_date", "value", "notes"]
        )
    vdf = pd.DataFrame(valuations)
    vdf["valuation_date"] = pd.to_datetime(vdf["valuation_date"])
    return vdf.rename(columns={
        "asset_name":     "Asset",
        "value":          "Value (AED)",
        "valuation_date": "Date",
        "category":       "Category",
    })


assets     = get_assets()
valuations = get_valuations()
df         = build_df(assets)
vdf        = build_val_df(valuations)

# Shared context dict passed to every page module
ctx = {
    "assets":         assets,
    "valuations":     valuations,
    "df":             df,
    "vdf":            vdf,
    "get_assets":     get_assets,
    "get_valuations": get_valuations,
    "username":       st.session_state.username,
}


# ════════════════════════════════════════════════════════════════════════════
# SIDEBAR NAVIGATION
# ════════════════════════════════════════════════════════════════════════════

# ── Logo ─────────────────────────────────────────────────────────────────────
if _logo_img:
    col_l, col_m, col_r = st.sidebar.columns([1, 3, 1])
    with col_m:
        st.image(_logo_img, use_container_width=True)
else:
    st.sidebar.title("🏗️")

st.sidebar.markdown(
    "<div style='text-align:center; color:#C9A84C; font-size:1.05rem;"
    " font-weight:800; letter-spacing:0.04em; margin-top:4px;'>"
    "Sawastik Emirates</div>"
    "<div style='text-align:center; color:rgba(245,240,232,0.55);"
    " font-size:0.72rem; margin-bottom:4px;'>Asset &amp; Finance Manager</div>",
    unsafe_allow_html=True,
)
st.sidebar.divider()

# ── Business unit selector (shown when >1 unit is active) ───────────────────
unit_names = [f"{u['icon']} {u['name']}" for u in BUSINESS_UNITS]

if len(BUSINESS_UNITS) > 1:
    selected_unit_label = st.sidebar.selectbox("Business Unit", unit_names)
    unit_index = unit_names.index(selected_unit_label)
else:
    unit_index = 0
    st.sidebar.markdown(f"**{unit_names[0]}**")

active_unit = BUSINESS_UNITS[unit_index]

# ── Page selector ─────────────────────────────────────────────────────────────
page_labels = [f"{p['icon']} {p['title']}" for p in active_unit["pages"]]
selected_page_label = st.sidebar.radio("Navigation", page_labels,
                                        label_visibility="collapsed")
page_index   = page_labels.index(selected_page_label)
active_page  = active_unit["pages"][page_index]

# ── Sidebar footer ────────────────────────────────────────────────────────────
st.sidebar.divider()
st.sidebar.caption(f"Logged in as **{st.session_state.username}**")
if not df.empty:
    st.sidebar.metric("Portfolio", f"AED {df['Total Value (AED)'].sum():,.0f}")
    st.sidebar.metric("Sawastik Share",
                      f"AED {df['Sawastik Value (AED)'].sum():,.0f}")
st.sidebar.divider()

# ── Dev bypass badge ──────────────────────────────────────────────────────────
if st.session_state.get("dev_bypass"):
    st.sidebar.markdown(
        "<div style='background:#162A4A; border:1px solid #C9A84C; "
        "border-radius:6px; padding:5px 10px; text-align:center; "
        "font-size:0.72rem; color:#C9A84C; letter-spacing:0.04em;'>"
        "⚡ Dev Bypass Active</div>",
        unsafe_allow_html=True,
    )

if st.sidebar.button("🚪 Logout", use_container_width=True):
    # Revoke any persistent session cookie
    _active_cookie = st.context.cookies.get(_COOKIE_NAME, "")
    if _active_cookie:
        revoke_session_token(_active_cookie)
        _clear_session_cookie()
    st.session_state.logged_in  = False
    st.session_state.username   = ""
    st.session_state.dev_bypass = False
    st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# DYNAMIC MODULE LOADER
# ════════════════════════════════════════════════════════════════════════════
module_path = f"modules.{active_unit['id']}.{active_page['id']}"
try:
    page_module = importlib.import_module(module_path)
    page_module.render(ctx)
except ModuleNotFoundError:
    st.error(
        f"Page module not found: `{module_path}`\n\n"
        f"Create `sawastik-dashboard/{module_path.replace('.', '/')}.py` "
        f"with a `render(ctx)` function to activate this page."
    )
except Exception as exc:
    st.exception(exc)
