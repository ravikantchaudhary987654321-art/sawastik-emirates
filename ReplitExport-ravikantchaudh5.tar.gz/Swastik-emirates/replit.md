# Sawastik Emirates - Asset & Finance Manager

A modular Streamlit dashboard for tracking real estate assets and partner financial shareholding across the UAE, backed by PostgreSQL.

## Run & Operate

- `cd sawastik-dashboard && streamlit run main.py` — run the Streamlit dashboard (port 5000)
- Workflow name: **Sawastik Emirates Dashboard**

## Stack

- Python 3.11
- Streamlit (dashboard UI)
- Pandas (data manipulation)
- Plotly (interactive charts)
- PostgreSQL (Replit managed) via `psycopg2-binary`
- bcrypt (password hashing)
- reportlab (PDF report generation)

## Where things live

```
sawastik-dashboard/
├── main.py                          ← central hub: auth gate + sidebar nav + module loader
├── config.py                        ← business unit & page registry (edit here to add units)
├── data.py                          ← PostgreSQL data access layer (all CRUD + auth)
├── report.py                        ← PDF report generator (reportlab)
├── app.py                           ← legacy monolith (kept as reference, not used)
├── modules/
│   ├── _base.py                     ← PageModule protocol + developer docs
│   ├── _template/
│   │   └── sample_page.py           ← copy this to bootstrap a new page
│   └── sawastik_emirates/           ← business unit folder
│       ├── dashboard.py
│       ├── portfolio.py
│       ├── add_asset.py
│       ├── edit_asset.py
│       ├── valuation_history.py
│       ├── partner_view.py
│       └── analytics.py
└── .streamlit/config.toml           ← server config (port 5000, headless)
```

## Adding a New Business Unit (e.g. Stocks, AI Ventures)

1. Create `modules/<unit_id>/` with an `__init__.py`
2. Add one `.py` file per page — each must expose `render(ctx: dict) -> None`
3. Add an entry to `BUSINESS_UNITS` in `config.py` — **no changes to `main.py` needed**

The sidebar will automatically show a business unit selector when more than one unit is active.

## Page Module Contract

Every page module must implement:

```python
PAGE_TITLE = "My Page"
PAGE_ICON  = "🗂️"

def render(ctx: dict) -> None:
    assets         = ctx["assets"]        # list[dict] — raw asset rows
    valuations     = ctx["valuations"]    # list[dict] — raw valuation rows
    df             = ctx["df"]            # pd.DataFrame — flat asset table
    vdf            = ctx["vdf"]           # pd.DataFrame — valuation table
    get_assets     = ctx["get_assets"]    # call .clear() after mutations
    get_valuations = ctx["get_valuations"]
    username       = ctx["username"]      # logged-in user
```

## Database Schema

- **assets** — id, name, category, location, total_value, purchase_date, status, created_at
- **asset_partners** — id, asset_id (FK → assets CASCADE), partner_name, share_pct
- **asset_valuations** — id, asset_id (FK → assets CASCADE), valuation_date, value, notes
- **users** — id, username (unique), email (unique), password_hash (bcrypt), created_at

## Features

- **Auth** — bcrypt login/signup gate; every session requires credentials; logout in sidebar
- **Dashboard** — 5 KPI cards, date-range filtered trend chart, red/green growth table, PDF download
- **Asset Portfolio** — filterable asset list, partner share breakdown, delete assets
- **Add Asset** — form with multi-partner share configuration (writes to DB)
- **Edit Asset** — pre-filled form with transactional update (asset + partners atomically)
- **Valuation History** — trend lines, appreciation table, log/delete valuations
- **Partner View** — per-partner investment summary and charts
- **Analytics** — grouped bars, waterfall chart, faceted history, status distribution

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- `DATABASE_URL` env var must be set (Replit managed PostgreSQL provides it automatically).
- Partner shares must sum to 100% when adding or editing an asset.
- `st.rerun()` is used (not `experimental_rerun`).
- Cache is cleared via `get_assets.clear()` / `get_valuations.clear()` after any mutation.
- `main.py` uses `importlib.import_module()` to load page modules dynamically — no if/elif chains.
