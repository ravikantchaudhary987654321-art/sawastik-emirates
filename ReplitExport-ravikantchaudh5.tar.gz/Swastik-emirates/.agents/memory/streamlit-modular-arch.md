---
name: Modular Streamlit architecture
description: Pattern used in sawastik-dashboard — dynamic importlib loader, ctx dict, config-driven nav
---

## The pattern

`main.py` is the only entry point. It:
1. Runs the auth gate (st.session_state)
2. Loads BUSINESS_UNITS from `config.py`
3. Builds sidebar nav from config (unit selector + page radio)
4. Calls `importlib.import_module(f"modules.{unit_id}.{page_id}")` and then `module.render(ctx)`

Each page module lives at `modules/<unit_id>/<page_id>.py` and must expose `render(ctx: dict) -> None`.

## ctx dict keys

assets, valuations, df, vdf, get_assets, get_valuations, username

## Adding a new business unit

1. Create `modules/<unit_id>/` with `__init__.py`
2. Add page files with `render(ctx)` and `PAGE_TITLE`, `PAGE_ICON` constants
3. Add entry to `BUSINESS_UNITS` in `config.py` — nothing else changes

**Why:** Avoids the 1000-line monolith anti-pattern in Streamlit; new business units are additive, not edits to core routing.

**How to apply:** Any future page addition should go into a module file, not into main.py. Sidebar unit selector auto-appears when len(BUSINESS_UNITS) > 1.

## Workflow command

`cd sawastik-dashboard && streamlit run main.py` (port 5000)
